import java.util.*;
import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = null;

        String line = br.readLine();
        if (line == null) return;
        int T = Integer.parseInt(line.trim());

        StringBuilder sb = new StringBuilder();

        while (T-- > 0) {
            while (st == null || !st.hasMoreTokens()) {
                line = br.readLine();
                if (line == null) break;
                st = new StringTokenizer(line);
            }
            if (st == null || !st.hasMoreTokens()) break;

            long N = Long.parseLong(st.nextToken());
            long M = N / 2;

            if (M < 1) {
                sb.append(0).append("\n");
                continue;
            }

            long sum = 0;
            for (long l = 1, r; l <= M; l = r + 1) {
                long q = N / l;
                r = Math.min(M, N / q);
                sum += q * (r - l + 1);
            }

            long ans = sum - M;
            sb.append(ans).append("\n");
        }

        System.out.print(sb);
    }
}
