"""
backend/app.py
Flask Application Server for Multi-Agent AI Business Assistant.
Exposes REST endpoints for Chat Orchestration, SQLite Analytics, Execution Logs, and Agent Metadata.
"""

import os
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

from .database import init_db, get_dashboard_stats, get_recent_logs
from .coordinator import CoordinatorAgent

# Determine frontend directory path
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.abspath(os.path.join(CURRENT_DIR, "..", "frontend"))

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")
CORS(app)

# Initialize database schema and coordinator singleton
init_db()
coordinator = CoordinatorAgent()


@app.route("/")
def serve_index():
    """Serves the main frontend dashboard and chat interface."""
    return send_from_directory(FRONTEND_DIR, "index.html")


@app.route("/<path:path>")
def serve_static(path):
    """Serves static assets (CSS, JS, images)."""
    return send_from_directory(FRONTEND_DIR, path)


@app.route("/api/health", methods=["GET"])
def health_check():
    """Simple health check endpoint."""
    return jsonify({
        "status": "healthy",
        "service": "Multi-Agent AI Business Assistant",
        "version": "1.0.0"
    })


@app.route("/api/chat", methods=["POST"])
def handle_chat():
    """
    Main endpoint for enterprise workflow requests.
    Invokes the Coordinator Agent and executes routing pipeline.
    """
    try:
        data = request.get_json(force=True, silent=True) or {}
        user_message = data.get("message", "").strip()

        if not user_message:
            return jsonify({
                "success": False,
                "error": "Message content cannot be blank."
            }), 400

        result = coordinator.process_request(user_message)
        return jsonify(result)
    except Exception as exc:
        return jsonify({
            "success": False,
            "error": f"Server encountered an error processing request: {str(exc)}"
        }), 500


@app.route("/api/stats", methods=["GET"])
def get_stats():
    """Returns real SQLite metrics for dashboard visualization."""
    try:
        stats = get_dashboard_stats()
        return jsonify({"success": True, "stats": stats})
    except Exception as exc:
        return jsonify({"success": False, "error": str(exc)}), 500


@app.route("/api/logs", methods=["GET"])
def get_logs():
    """Returns recent audit execution records from SQLite database."""
    try:
        limit = request.args.get("limit", default=25, type=int)
        logs = get_recent_logs(limit=limit)
        return jsonify({"success": True, "logs": logs})
    except Exception as exc:
        return jsonify({"success": False, "error": str(exc)}), 500


@app.route("/api/agents", methods=["GET"])
def get_agents():
    """Returns registry of specialized agents and their Week 1 status."""
    agents_info = [
        {
            "id": "hr",
            "name": "HR Agent",
            "module": "backend.agents.hr_agent.HRAgent",
            "status": "Fully Functional",
            "badge": "Active (Functional)",
            "description": "Automates employee onboarding checklists, staff directory lookups, and leave balance/policy management.",
            "capabilities": ["Employee Onboarding", "Leave Management", "Staff Directory Queries"],
            "example_query": "I want to onboard a new employee named Alice."
        },
        {
            "id": "finance",
            "name": "Finance Agent",
            "module": "backend.agents.finance_agent.FinanceAgent",
            "status": "Fully Functional",
            "badge": "Active (Functional)",
            "description": "Calculates gross-to-net salary slips, statutory deductions (PF, Tax, PT), and persists payroll runs.",
            "capabilities": ["Salary Breakdown", "Statutory PF/Tax Computation", "Payroll Slip Archival"],
            "example_query": "Calculate the monthly salary for an employee with a basic salary of 40000."
        },
        {
            "id": "coding",
            "name": "Coding Agent",
            "module": "backend.agents.coding_agent.CodingAgent",
            "status": "Modular Prototype",
            "badge": "Active (Prototype)",
            "description": "Offers code debugging protocols, exception tracing strategies, and structured software templates.",
            "capabilities": ["Python Code Debugging", "Syntax Error Triage", "Boilerplate Generation"],
            "example_query": "Help me debug this Python code."
        },
        {
            "id": "email",
            "name": "Email Agent",
            "module": "backend.agents.email_agent.EmailAgent",
            "status": "Working Implementation",
            "badge": "Active (Functional Drafter)",
            "description": "Drafts polished corporate correspondence, project sign-offs, and formal stakeholder communications.",
            "capabilities": ["Project Approval Emails", "Leave Notice Drafting", "Meeting Agendas"],
            "example_query": "Draft an email requesting project approval."
        },
        {
            "id": "data_analysis",
            "name": "Data Analysis Agent",
            "module": "backend.agents.data_analysis_agent.DataAnalysisAgent",
            "status": "Fully Functional (SQLite)",
            "badge": "Active (Functional)",
            "description": "Aggregates quarterly enterprise sales metrics, calculates regional growth rates, and formats KPI summaries.",
            "capabilities": ["Sales Data Aggregation", "Territory Growth Comparison", "Executive KPI Summaries"],
            "example_query": "Analyze the sales data."
        },
        {
            "id": "customer_support",
            "name": "Customer Support Agent",
            "module": "backend.agents.customer_support_agent.CustomerSupportAgent",
            "status": "Fully Functional (SQLite)",
            "badge": "Active (Functional)",
            "description": "Classifies incident severity, generates tracked support tickets in SQLite, and formats triage scripts.",
            "capabilities": ["Incident Triage", "SQLite Ticket Generation", "SLA Priority Assignment"],
            "example_query": "A customer wants help with a product issue."
        }
    ]
    return jsonify({"success": True, "agents": agents_info})


if __name__ == "__main__":
    print(f"Starting Multi-Agent AI Business Assistant on port 5000...")
    print(f"Serving frontend from: {FRONTEND_DIR}")
    app.run(host="127.0.0.1", port=5000, debug=True)
