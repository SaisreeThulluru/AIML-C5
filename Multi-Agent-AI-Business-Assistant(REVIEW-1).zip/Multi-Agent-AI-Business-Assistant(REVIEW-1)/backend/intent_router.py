"""
backend/intent_router.py
Modular Intent Routing Engine for Multi-Agent AI Business Assistant.
Classifies user requests into enterprise domains (HR, Finance, Coding, Email, Data Analysis, Customer Support).
Designed for Week 1 rule/keyword matching with clean abstraction for future LLM integration.
"""

import re
from typing import Dict, Any, List, Tuple


class IntentRouter:
    """
    Modular Intent Classification & Routing Engine.
    Maps user requests to the appropriate specialized enterprise agent.
    """

    AGENT_MAP = {
        "hr": "HR Agent",
        "finance": "Finance Agent",
        "coding": "Coding Agent",
        "email": "Email Agent",
        "data_analysis": "Data Analysis Agent",
        "customer_support": "Customer Support Agent"
    }

    # Intent keyword rules with weights
    INTENT_KEYWORDS = {
        "hr": {
            "keywords": [
                "onboard", "onboarding", "new employee", "employee", "leave", "vacation",
                "sick leave", "casual leave", "pto", "hire", "hiring", "induction", 
                "human resources", "staff", "attendance", "resignation", "joining date",
                "employee details", "employee list", "checklist"
            ],
            "patterns": [
                r"\bonboard(?:ing)?\b",
                r"\bnew employee\b",
                r"\bleave balance\b",
                r"\bapply (?:for )?leave\b",
                r"\bemployee details\b"
            ]
        },
        "finance": {
            "keywords": [
                "salary", "payroll", "basic salary", "monthly salary", "payslip", 
                "compensation", "ctc", "hra", "allowance", "deduction", "provident fund", 
                "pf", "tax", "income tax", "tds", "net pay", "gross pay", "remuneration", 
                "financial report", "invoice", "reimbursement"
            ],
            "patterns": [
                r"\bsalary\b",
                r"\bpayroll\b",
                r"\bcalculate (?:the )?(?:monthly )?salary\b",
                r"\bbasic salary\b",
                r"\bnet salary\b"
            ]
        },
        "coding": {
            "keywords": [
                "code", "coding", "debug", "debugging", "python", "javascript", 
                "script", "syntax", "error", "traceback", "function", "class", 
                "algorithm", "regex", "refactor", "unit test", "bug fix", "program"
            ],
            "patterns": [
                r"\bdebug(?:ging)?\b",
                r"\bpython code\b",
                r"\bhelp me debug\b",
                r"\bwrite a? ?function\b",
                r"\bfix this code\b"
            ]
        },
        "email": {
            "keywords": [
                "email", "draft", "drafting", "mail", "write an email", "compose", 
                "template", "subject line", "letter", "out of office", "approval request", 
                "follow-up email", "formal mail"
            ],
            "patterns": [
                r"\bdraft (?:an? )?email\b",
                r"\bwrite (?:an? )?email\b",
                r"\bemail requesting\b",
                r"\bcompose (?:a? )?message\b"
            ]
        },
        "data_analysis": {
            "keywords": [
                "analyze", "analysis", "sales data", "data analysis", "revenue", 
                "dataset", "quarterly", "growth rate", "units sold", "metrics", 
                "trend", "statistics", "summary stats", "insights", "kpi"
            ],
            "patterns": [
                r"\banalyze (?:the )?sales data\b",
                r"\bdata analysis\b",
                r"\bsales report\b",
                r"\brevenue analysis\b"
            ]
        },
        "customer_support": {
            "keywords": [
                "customer", "support", "ticket", "product issue", "complaint", 
                "refund", "issue", "troubleshoot", "client query", "feedback", 
                "service desk", "glitch", "helpdesk"
            ],
            "patterns": [
                r"\bcustomer wants help\b",
                r"\bproduct issue\b",
                r"\bsupport ticket\b",
                r"\bcustomer (?:issue|query|complaint)\b"
            ]
        }
    }

    def __init__(self, mode: str = "keyword"):
        """
        Initializes the intent router.
        mode: 'keyword' (default for Week 1) or 'llm' (extensible placeholder)
        """
        self.mode = mode

    def route(self, user_query: str) -> Dict[str, Any]:
        """
        Dispatches request to active classification strategy.
        Returns dictionary containing detected intent, confidence score,
        matched keywords, and selected agent name.
        """
        if not user_query or not user_query.strip():
            return {
                "intent": "unknown",
                "confidence": 0.0,
                "selected_agent": "Coordinator Agent",
                "matched_keywords": [],
                "classifier": self.mode
            }

        if self.mode == "keyword":
            return self._keyword_classify(user_query)
        elif self.mode == "llm":
            return self._llm_classify(user_query)
        else:
            return self._keyword_classify(user_query)

    def _keyword_classify(self, text: str) -> Dict[str, Any]:
        """
        Scoring algorithm combining exact regex pattern matches and tokenized keyword density.
        """
        normalized_text = text.lower().strip()
        scores = {}
        matched_details = {}

        for intent, config in self.INTENT_KEYWORDS.items():
            intent_score = 0.0
            matches = []

            # Check strong regex patterns (weight 3.0 each)
            for pattern in config["patterns"]:
                if re.search(pattern, normalized_text):
                    intent_score += 3.5
                    matches.append(f"pattern:{pattern}")

            # Check keyword tokens (weight 1.2 each)
            for kw in config["keywords"]:
                # Use word boundary search for keyword
                if re.search(r'\b' + re.escape(kw) + r'\b', normalized_text):
                    intent_score += 1.5
                    matches.append(kw)

            scores[intent] = intent_score
            matched_details[intent] = matches

        # Find best candidate
        best_intent = max(scores, key=scores.get)
        best_score = scores[best_intent]

        # Calculate confidence normalized between 0.0 and 1.0
        if best_score == 0:
            return {
                "intent": "general",
                "confidence": 0.20,
                "selected_agent": "Customer Support Agent",
                "matched_keywords": [],
                "classifier": "keyword"
            }

        # Normalize confidence: min 0.65 for positive match, capping at 0.98
        confidence = min(0.98, round(0.60 + (best_score * 0.08), 2))

        return {
            "intent": best_intent,
            "confidence": confidence,
            "selected_agent": self.AGENT_MAP.get(best_intent, "Coordinator Agent"),
            "matched_keywords": matched_details[best_intent],
            "classifier": "rule_based_keyword_engine"
        }

    def _llm_classify(self, text: str) -> Dict[str, Any]:
        """
        Placeholder / Architecture hook for future LLM-based intent routing.
        Can connect to OpenAI / Gemini / Ollama / HuggingFace.
        """
        # For Week 1 architecture: fallback gracefully to rule-based classifier
        result = self._keyword_classify(text)
        result["classifier"] = "llm_fallback_ready"
        return result
