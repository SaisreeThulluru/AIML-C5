"""
backend/routes/tasks.py
Task Suite API Endpoints for Module M1.
Loads cross-department enterprise benchmark tasks from datasets/sample_tasks.json.
"""

import json
import os
from fastapi import APIRouter, HTTPException, Query, status
from typing import List, Optional
from backend.schemas import TaskItem

router = APIRouter(prefix="", tags=["Enterprise Task Suite"])

DATASET_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "datasets",
    "sample_tasks.json"
)


def load_tasks() -> List[dict]:
    """Loads benchmark enterprise tasks from local JSON dataset."""
    if not os.path.exists(DATASET_PATH):
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Benchmark task dataset 'datasets/sample_tasks.json' not found."
        )
    with open(DATASET_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


@router.get(
    "/tasks",
    response_model=List[TaskItem],
    summary="List all benchmark enterprise tasks",
    description="Retrieve the 15 Module M1 benchmark tasks with optional department and difficulty filters."
)
def list_tasks(
    department: Optional[str] = Query(None, description="Filter by department, e.g. 'Human Resources' or 'Finance'"),
    difficulty: Optional[str] = Query(None, description="Filter by difficulty level: Easy, Medium, Hard")
):
    tasks = load_tasks()
    if department:
        tasks = [t for t in tasks if t["department"].lower() == department.lower()]
    if difficulty:
        tasks = [t for t in tasks if t.get("difficulty_level", "").lower() == difficulty.lower()]
    return tasks


@router.get(
    "/tasks/{task_id}",
    response_model=TaskItem,
    summary="Retrieve single task specification",
    description="Get input parameters, expected outcome, and ground-truth verification criteria for a task ID."
)
def get_task(task_id: str):
    tasks = load_tasks()
    for task in tasks:
        if task["task_id"].upper() == task_id.upper():
            return task
    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail=f"Task with ID '{task_id}' not found in benchmark dataset."
    )
