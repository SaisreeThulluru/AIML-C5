"""
backend/routes/hr.py
Mock HR System FastAPI HTTP Endpoints.
Delegates business queries to backend.services.hr_service.
"""

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from typing import List, Optional

from backend.database import get_db
from backend.schemas import EmployeeResponse, LeaveBalanceResponse
from backend.services.hr_service import (
    get_all_employees,
    get_employee_by_id,
    search_employees,
    get_employee_leave_balance,
)

router = APIRouter(prefix="", tags=["Human Resources"])


@router.get(
    "/employees",
    response_model=List[EmployeeResponse],
    summary="List or search all enterprise employees",
    description="Retrieve full employee directory with optional filters for department and search keywords."
)
def list_employees(
    department: Optional[str] = Query(None, description="Filter by department name, e.g. Engineering"),
    search: Optional[str] = Query(None, description="Search query matching name, email, or role"),
    db: Session = Depends(get_db)
):
    employees = get_all_employees(db, department=department, search=search)
    return employees


@router.get(
    "/employees/{employee_id}",
    response_model=EmployeeResponse,
    summary="Retrieve single employee profile",
    description="Fetch complete employee details using their unique employee ID (e.g. EMP-001)."
)
def get_employee(employee_id: str, db: Session = Depends(get_db)):
    emp = get_employee_by_id(db, employee_id)
    if not emp:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Employee with ID '{employee_id}' not found in enterprise records."
        )
    return emp


@router.get(
    "/employees/{employee_id}/leave",
    response_model=LeaveBalanceResponse,
    summary="Retrieve employee leave balance",
    description="Calculates remaining paid time off (PTO) and approved leave history for the given employee."
)
def get_leave_balance(employee_id: str, db: Session = Depends(get_db)):
    balance = get_employee_leave_balance(db, employee_id)
    if not balance:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Employee with ID '{employee_id}' not found. Cannot calculate leave balance."
        )
    return balance
