"""
backend/agents/finance_agent.py
Specialized Finance Agent for Multi-Agent AI Business Assistant.
Handles salary computation, payroll processing, statutory deductions, and compensation breakdown.
STATUS: Fully Functional (Week 1 Core Agent with SQLite Integration).
"""

import re
from datetime import datetime
from typing import Dict, Any
from ..database import get_db_connection


class FinanceAgent:
    """
    Enterprise Finance & Payroll Agent.
    Calculates monthly compensation structures, gross-to-net salary reconciliations,
    statutory deductions (PF, Tax, PT), and logs payroll runs to SQLite.
    """

    AGENT_NAME = "Finance Agent"
    STATUS_TYPE = "Fully Functional"

    def execute(self, user_request: str) -> Dict[str, Any]:
        """
        Main entry point for finance requests.
        Evaluates salary calculations, payroll queries, and financial summaries.
        """
        request_lower = user_request.lower()

        # Check for salary or payroll calculation
        if any(term in request_lower for term in ["salary", "payroll", "basic", "payslip", "calculate", "ctc"]):
            return self._calculate_salary(user_request)

        # Check for payroll records / history
        elif any(term in request_lower for term in ["payroll report", "records", "history", "expenses"]):
            return self._get_payroll_records()

        # General Finance
        else:
            return self._calculate_salary(user_request)

    def _calculate_salary(self, request: str) -> Dict[str, Any]:
        """
        Calculates salary breakdown based on extracted basic salary.
        """
        # Extract numeric value for basic salary
        # Looks for patterns like "basic salary of 40000", "basic 40000", "salary 50000", "40000"
        numbers = re.findall(r"(?:basic\s*(?:salary)?\s*(?:of)?\s*[:$₹]?\s*|\b)(\d+(?:,\d+)*(?:\.\d+)?)", request, re.IGNORECASE)

        basic_salary = 40000.0  # Default test value if unspecified
        if numbers:
            # Clean commas and parse
            for candidate in numbers:
                clean_num = candidate.replace(",", "")
                try:
                    val = float(clean_num)
                    if val >= 1000:  # Reasonable salary threshold
                        basic_salary = val
                        break
                except ValueError:
                    continue

        # Enterprise Payroll Rules
        hra = round(basic_salary * 0.40, 2)          # 40% House Rent Allowance
        da = round(basic_salary * 0.20, 2)           # 20% Dearness Allowance
        conveyance = 2500.00                         # Fixed standard allowance
        medical = 1500.00                            # Fixed medical allowance
        
        gross_monthly = round(basic_salary + hra + da + conveyance + medical, 2)

        # Statutory Deductions
        pf = round(basic_salary * 0.12, 2)           # 12% Provident Fund
        professional_tax = 200.00                    # Fixed standard PT
        
        # Progressive Estimated Income Tax (TDS)
        annual_gross = gross_monthly * 12
        if annual_gross > 1000000:
            monthly_tax = round(gross_monthly * 0.15, 2)
        elif annual_gross > 600000:
            monthly_tax = round(gross_monthly * 0.08, 2)
        else:
            monthly_tax = round(gross_monthly * 0.03, 2)

        total_deductions = round(pf + professional_tax + monthly_tax, 2)
        net_monthly = round(gross_monthly - total_deductions, 2)
        annual_ctc = round((gross_monthly + pf) * 12, 2)  # CTC includes employer PF matching

        # Extract employee name if mentioned, else default
        name_match = re.search(r"(?:for\s+(?:an?\s+)?employee\s+(?:named\s+)?)([A-Z][a-z]+)", request, re.IGNORECASE)
        emp_name = name_match.group(1).title() if name_match else "Standard Employee"

        # Log payroll calculation record in SQLite
        current_date = datetime.now()
        month_name = current_date.strftime("%B")
        year_num = current_date.year

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO payroll_records 
            (employee_name, basic_salary, hra, da, pf, tax, gross_salary, net_salary, month, year, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (emp_name, basic_salary, hra, da, pf, monthly_tax + professional_tax, gross_monthly, net_monthly, month_name, year_num, current_date.strftime("%Y-%m-%d %H:%M:%S")))
        record_id = cursor.lastrowid
        conn.commit()
        conn.close()

        formatted_response = (
            f"### Official Payroll Computation & Salary Slip\n\n"
            f"**Employee:** `{emp_name}` | **Pay Period:** `{month_name} {year_num}` | **Slip ID:** `PAY-{record_id:04d}`\n\n"
            f"#### 1. Earnings Breakdown (Monthly):\n"
            f"| Component | Calculation Basis | Amount |\n"
            f"| :--- | :--- | :--- |\n"
            f"| **Basic Salary** | Base Fixed Compensation | **${basic_salary:,.2f}** |\n"
            f"| **House Rent Allowance (HRA)** | 40% of Basic Salary | ${hra:,.2f} |\n"
            f"| **Dearness Allowance (DA)** | 20% of Basic Salary | ${da:,.2f} |\n"
            f"| **Conveyance Allowance** | Fixed Monthly Norm | ${conveyance:,.2f} |\n"
            f"| **Medical Allowance** | Fixed Monthly Norm | ${medical:,.2f} |\n"
            f"| **Gross Monthly Earnings** | *Sum of all earnings* | **${gross_monthly:,.2f}** |\n\n"
            f"#### 2. Statutory Deductions:\n"
            f"| Deduction | Rate / Norm | Amount |\n"
            f"| :--- | :--- | :--- |\n"
            f"| **Employee Provident Fund (PF)** | 12% of Basic | ${pf:,.2f} |\n"
            f"| **Income Tax (TDS)** | Est. Tax Slab Deduction | ${monthly_tax:,.2f} |\n"
            f"| **Professional Tax (PT)** | Statutory Municipal Fee | ${professional_tax:,.2f} |\n"
            f"| **Total Deductions** | *Sum of all deductions* | **${total_deductions:,.2f}** |\n\n"
            f"### 💵 Net Take-Home Salary: **${net_monthly:,.2f} / month**\n"
            f"- **Estimated Annual CTC:** `${annual_ctc:,.2f}`\n"
            f"- **Annual Net Take-Home:** `${(net_monthly * 12):,.2f}`\n\n"
            f"> *Record persisted into SQLite `payroll_records` (Entry #{record_id}). Ready for direct deposit export.*"
        )

        return {
            "status": "SUCCESS",
            "agent": self.AGENT_NAME,
            "agent_type": self.STATUS_TYPE,
            "action": "salary_calculation_completed",
            "summary": f"Calculated Net Monthly Salary of ${net_monthly:,.2f} on Basic of ${basic_salary:,.2f}.",
            "formatted_response": formatted_response,
            "data": {
                "record_id": record_id,
                "employee": emp_name,
                "basic_salary": basic_salary,
                "hra": hra,
                "da": da,
                "conveyance": conveyance,
                "medical": medical,
                "gross_monthly": gross_monthly,
                "pf": pf,
                "tax": monthly_tax,
                "professional_tax": professional_tax,
                "total_deductions": total_deductions,
                "net_monthly": net_monthly,
                "annual_ctc": annual_ctc
            }
        }

    def _get_payroll_records(self) -> Dict[str, Any]:
        """Fetches historical payroll calculation records."""
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id, employee_name, basic_salary, gross_salary, net_salary, month, year FROM payroll_records ORDER BY id DESC LIMIT 5")
        records = [dict(r) for r in cursor.fetchall()]
        conn.close()

        if not records:
            return {
                "status": "SUCCESS",
                "agent": self.AGENT_NAME,
                "agent_type": self.STATUS_TYPE,
                "action": "payroll_history",
                "summary": "No payroll slips generated yet.",
                "formatted_response": "No previous payroll runs found in SQLite. Calculate a salary to create records.",
                "data": {"records": []}
            }

        formatted_response = "### Recent Payroll Processing Records (SQLite Database)\n\n"
        formatted_response += "| Slip ID | Employee | Basic Pay | Gross Pay | Net Pay | Pay Period |\n"
        formatted_response += "| :--- | :--- | :--- | :--- | :--- | :--- |\n"

        for r in records:
            formatted_response += (
                f"| `PAY-{r['id']:04d}` | {r['employee_name']} | ${r['basic_salary']:,.2f} | "
                f"${r['gross_salary']:,.2f} | **${r['net_salary']:,.2f}** | {r['month']} {r['year']} |\n"
            )

        return {
            "status": "SUCCESS",
            "agent": self.AGENT_NAME,
            "agent_type": self.STATUS_TYPE,
            "action": "payroll_history",
            "summary": f"Fetched {len(records)} recent payroll records.",
            "formatted_response": formatted_response,
            "data": {"records": records}
        }
