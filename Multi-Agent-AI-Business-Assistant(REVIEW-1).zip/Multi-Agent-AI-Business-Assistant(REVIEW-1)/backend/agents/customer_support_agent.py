"""
backend/agents/customer_support_agent.py
Specialized Customer Support Agent for Multi-Agent AI Business Assistant.
Handles customer incident triage, ticketing creation in SQLite, and resolution workflows.
STATUS: Fully Functional with SQLite Ticketing System.
"""

import random
from datetime import datetime
from typing import Dict, Any
from ..database import get_db_connection


class CustomerSupportAgent:
    """
    Enterprise Customer Support & Service Desk Agent.
    Categorizes incoming client inquiries, provisions support tickets in SQLite,
    evaluates SLA severity priorities, and delivers standardized resolution protocols.
    """

    AGENT_NAME = "Customer Support Agent"
    STATUS_TYPE = "Fully Functional (SQLite-Backed)"

    def execute(self, user_request: str) -> Dict[str, Any]:
        """
        Processes customer support issues, creates support ticket, and provides triage guidance.
        """
        request_lower = user_request.lower()

        # Categorize issue
        category = "Product Issue"
        priority = "High" if any(w in request_lower for w in ["urgent", "down", "critical", "broken"]) else "Medium"

        if "billing" in request_lower or "invoice" in request_lower or "payment" in request_lower:
            category = "Billing & Payments"
            priority = "Medium"
        elif "login" in request_lower or "auth" in request_lower or "password" in request_lower:
            category = "Authentication / Access"
            priority = "High"

        # Generate unique ticket number
        ticket_code = f"TKT-2026-{random.randint(2000, 9999)}"
        customer_name = "Valued Enterprise Client"
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Persist ticket into SQLite
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO support_tickets 
            (ticket_code, customer_name, issue_category, description, priority, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (ticket_code, customer_name, category, user_request, priority, "Open", now_str))
        ticket_id = cursor.lastrowid
        conn.commit()
        conn.close()

        formatted_response = (
            f"### Customer Service Incident Triage & Ticket Created\n\n"
            f"**Status:** `[Agent Mode: {self.STATUS_TYPE}]`\n\n"
            f"| Ticket Parameter | Specification |\n"
            f"| :--- | :--- |\n"
            f"| **Incident Code** | **`{ticket_code}`** (DB Record #{ticket_id}) |\n"
            f"| **Classification** | `{category}` |\n"
            f"| **SLA Severity** | **{priority} Priority** |\n"
            f"| **Current Status** | `Open - Queued for Support Specialist` |\n"
            f"| **Response Target** | `< 2 Hours (Enterprise SLA)` |\n\n"
            f"#### Automated First-Response Protocol:\n"
            f"1. **Acknowledgment Dispatched:** Immediate confirmation receipt logged for client.\n"
            f"2. **Diagnostic Triage Checklist:**\n"
            f"   - Confirm client software version and platform environment.\n"
            f"   - Request reproduction steps and screenshots/error logs.\n"
            f"   - Verify cloud service health status (All regional clusters reporting operational).\n"
            f"3. **Specialist Escalation:** Ticket routed to Tier-2 Application Engineering desk.\n\n"
            f"#### Recommended Customer Communication Script:\n"
            f"```text\n"
            f"Hello,\n"
            f"Thank you for contacting Enterprise Support. We have logged ticket {ticket_code} regarding your product inquiry.\n"
            f"Our technical engineering team is actively investigating. We will provide our next update within 2 hours.\n"
            f"```"
        )

        return {
            "status": "SUCCESS",
            "agent": self.AGENT_NAME,
            "agent_type": self.STATUS_TYPE,
            "action": "support_ticket_created",
            "summary": f"Created {priority}-priority support ticket {ticket_code} in SQLite.",
            "formatted_response": formatted_response,
            "data": {
                "ticket_id": ticket_id,
                "ticket_code": ticket_code,
                "priority": priority,
                "category": category,
                "status": "Open"
            }
        }
