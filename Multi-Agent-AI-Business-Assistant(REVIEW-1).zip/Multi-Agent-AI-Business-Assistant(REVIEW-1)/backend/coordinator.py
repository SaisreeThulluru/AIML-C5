"""
backend/coordinator.py
Central Coordinator Agent for Multi-Agent AI Business Assistant.
Orchestrates request intake, intent classification, agent dispatching, execution timing,
and SQLite execution persistence.
"""

import time
from datetime import datetime
from typing import Dict, Any

from .intent_router import IntentRouter
from .database import log_execution
from .agents.hr_agent import HRAgent
from .agents.finance_agent import FinanceAgent
from .agents.coding_agent import CodingAgent
from .agents.email_agent import EmailAgent
from .agents.data_analysis_agent import DataAnalysisAgent
from .agents.customer_support_agent import CustomerSupportAgent


class CoordinatorAgent:
    """
    Central Orchestrator of the Multi-Agent System.
    Manages workflow routing, lifecycle execution steps, telemetry,
    and returns a unified payload to the web interface.
    """

    def __init__(self):
        self.router = IntentRouter(mode="keyword")
        
        # Instantiate agent registry
        self.agents = {
            "hr": HRAgent(),
            "finance": FinanceAgent(),
            "coding": CodingAgent(),
            "email": EmailAgent(),
            "data_analysis": DataAnalysisAgent(),
            "customer_support": CustomerSupportAgent()
        }

    def process_request(self, user_request: str) -> Dict[str, Any]:
        """
        Coordinates end-to-end execution of a user prompt.
        Measures individual step execution latencies and logs audit records to SQLite.
        """
        overall_start_time = time.perf_counter()
        execution_steps = []

        # Step 1: Input Validation
        step1_start = time.perf_counter()
        clean_request = user_request.strip() if user_request else ""
        if not clean_request:
            return {
                "success": False,
                "error": "Request cannot be empty.",
                "response": "Please enter a valid enterprise request."
            }
        
        step1_duration = round((time.perf_counter() - step1_start) * 1000, 2)
        execution_steps.append({
            "step": "Input Validation & Pre-processing",
            "detail": f"Received query with length {len(clean_request)} chars.",
            "duration_ms": step1_duration
        })

        # Step 2: Intent Classification
        step2_start = time.perf_counter()
        routing_info = self.router.route(clean_request)
        intent = routing_info["intent"]
        confidence = routing_info["confidence"]
        agent_name = routing_info["selected_agent"]
        matched_kw = routing_info.get("matched_keywords", [])

        step2_duration = round((time.perf_counter() - step2_start) * 1000, 2)
        execution_steps.append({
            "step": "Intent Classification Engine",
            "detail": f"Classified intent as '{intent}' with {int(confidence*100)}% confidence. Triggers: {matched_kw}",
            "duration_ms": step2_duration
        })

        # Step 3: Agent Selection & Dispatch
        step3_start = time.perf_counter()
        target_agent = self.agents.get(intent)
        if not target_agent:
            target_agent = self.agents["customer_support"]  # Fallback agent
            agent_name = "Customer Support Agent"

        step3_duration = round((time.perf_counter() - step3_start) * 1000, 2)
        execution_steps.append({
            "step": "Agent Dispatching",
            "detail": f"Routed task to specialized worker: {agent_name} ({getattr(target_agent, 'STATUS_TYPE', 'Modular')}).",
            "duration_ms": step3_duration
        })

        # Step 4: Specialized Agent Execution
        step4_start = time.perf_counter()
        try:
            agent_result = target_agent.execute(clean_request)
            task_status = agent_result.get("status", "SUCCESS")
            response_content = agent_result.get("formatted_response", "")
            agent_data = agent_result.get("data", {})
            agent_type = agent_result.get("agent_type", "Standard")
        except Exception as exc:
            task_status = "FAILED"
            response_content = f"⚠️ Error during agent execution: {str(exc)}"
            agent_data = {}
            agent_type = "Error"

        step4_duration = round((time.perf_counter() - step4_start) * 1000, 2)
        execution_steps.append({
            "step": f"Task Execution ({agent_name})",
            "detail": f"Task finished with status: {task_status} in {step4_duration}ms.",
            "duration_ms": step4_duration
        })

        # Overall timing
        total_time_ms = round((time.perf_counter() - overall_start_time) * 1000, 2)

        # Step 5: Persistent Execution Logging to SQLite
        step5_start = time.perf_counter()
        log_id = log_execution(
            user_request=clean_request,
            detected_intent=intent,
            selected_agent=agent_name,
            confidence=confidence,
            task_status=task_status,
            agent_response=response_content,
            execution_time_ms=total_time_ms,
            details={
                "steps": execution_steps,
                "data": agent_data,
                "agent_type": agent_type
            }
        )
        step5_duration = round((time.perf_counter() - step5_start) * 1000, 2)
        execution_steps.append({
            "step": "SQLite Audit Trail Persistence",
            "detail": f"Logged audit record #{log_id} to database.",
            "duration_ms": step5_duration
        })

        return {
            "success": task_status == "SUCCESS",
            "log_id": log_id,
            "request": clean_request,
            "detected_intent": intent,
            "confidence": confidence,
            "selected_agent": agent_name,
            "agent_type": agent_type,
            "response": response_content,
            "data": agent_data,
            "execution_steps": execution_steps,
            "total_time_ms": total_time_ms,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
