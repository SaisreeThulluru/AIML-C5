"""
backend/models.py
SQLAlchemy Declarative ORM Models for Enterprise Database.
Covers 7 core enterprise domains:
- Departments
- Employees
- Leave Records
- Payroll Records
- Reimbursements
- Email Drafts
- Support Tickets
"""

from sqlalchemy import Column, Integer, String, Float, Text, ForeignKey, DateTime
from sqlalchemy.orm import declarative_base, relationship
from datetime import datetime

Base = declarative_base()


class Department(Base):
    __tablename__ = "departments"

    id = Column(Integer, primary_key=True, index=True)
    department_id = Column(String(32), unique=True, index=True, nullable=False)
    name = Column(String(100), unique=True, nullable=False)
    budget = Column(Float, default=0.0)
    manager_name = Column(String(100), nullable=False)

    # Relationships
    employees = relationship("Employee", back_populates="dept_relation")


class Employee(Base):
    __tablename__ = "employees"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(String(32), unique=True, index=True, nullable=False)
    full_name = Column(String(120), nullable=False)
    email = Column(String(120), unique=True, index=True, nullable=False)
    department = Column(String(100), ForeignKey("departments.name"), nullable=False)
    role = Column(String(100), nullable=False)
    base_salary = Column(Float, nullable=False)
    joining_date = Column(String(32), nullable=False)
    status = Column(String(32), default="Active")

    # Relationships
    dept_relation = relationship("Department", back_populates="employees")
    leave_records = relationship("LeaveRecord", back_populates="employee")
    payroll_records = relationship("Payroll", back_populates="employee")
    reimbursements = relationship("Reimbursement", back_populates="employee")


class LeaveRecord(Base):
    __tablename__ = "leave_records"

    id = Column(Integer, primary_key=True, index=True)
    record_id = Column(String(32), unique=True, index=True, nullable=False)
    employee_id = Column(String(32), ForeignKey("employees.employee_id"), nullable=False)
    leave_type = Column(String(50), default="Annual")
    start_date = Column(String(32), nullable=False)
    end_date = Column(String(32), nullable=False)
    days_requested = Column(Integer, nullable=False)
    status = Column(String(32), default="Approved")  # Approved, Pending, Rejected
    total_annual_allocated = Column(Integer, default=24)

    # Relationships
    employee = relationship("Employee", back_populates="leave_records")


class Payroll(Base):
    __tablename__ = "payroll"

    id = Column(Integer, primary_key=True, index=True)
    payroll_id = Column(String(32), unique=True, index=True, nullable=False)
    employee_id = Column(String(32), ForeignKey("employees.employee_id"), nullable=False)
    month = Column(String(20), nullable=False)
    year = Column(Integer, nullable=False)
    base_salary = Column(Float, nullable=False)
    allowances = Column(Float, default=0.0)
    gross_salary = Column(Float, nullable=False)
    tax_deductions = Column(Float, nullable=False)
    provident_fund = Column(Float, nullable=False)
    total_deductions = Column(Float, nullable=False)
    net_pay = Column(Float, nullable=False)
    payment_status = Column(String(32), default="Paid")

    # Relationships
    employee = relationship("Employee", back_populates="payroll_records")


class Reimbursement(Base):
    __tablename__ = "reimbursements"

    id = Column(Integer, primary_key=True, index=True)
    claim_id = Column(String(32), unique=True, index=True, nullable=False)
    employee_id = Column(String(32), ForeignKey("employees.employee_id"), nullable=False)
    category = Column(String(50), nullable=False)
    amount = Column(Float, nullable=False)
    submission_date = Column(String(32), nullable=False)
    status = Column(String(32), default="Pending")  # Approved, Flagged, Pending
    notes = Column(Text, nullable=True)

    # Relationships
    employee = relationship("Employee", back_populates="reimbursements")


class EmailDraft(Base):
    __tablename__ = "email_drafts"

    id = Column(Integer, primary_key=True, index=True)
    draft_id = Column(String(32), unique=True, index=True, nullable=False)
    sender = Column(String(120), nullable=False)
    recipient = Column(String(120), nullable=False)
    subject = Column(String(255), nullable=False)
    body = Column(Text, nullable=False)
    related_incident = Column(String(64), nullable=True)
    status = Column(String(32), default="Draft")  # Draft, Ready for Dispatch, Sent
    created_at = Column(String(64), default=datetime.utcnow().isoformat)


class SupportTicket(Base):
    __tablename__ = "support_tickets"

    id = Column(Integer, primary_key=True, index=True)
    ticket_id = Column(String(32), unique=True, index=True, nullable=False)
    customer_name = Column(String(120), nullable=False)
    customer_tier = Column(String(50), default="Standard")  # Standard, Enterprise Gold
    issue_description = Column(Text, nullable=False)
    priority = Column(String(32), default="Medium")  # Low, Medium, High, Critical
    status = Column(String(32), default="Open")  # Open, In Progress, Resolved, Closed
    assigned_team = Column(String(100), default="Customer Support")
    resolution_time_hours = Column(Float, nullable=True)
    sla_met = Column(Integer, default=1)  # 1 for True, 0 for False
    csat_score = Column(Integer, nullable=True)  # 1 to 5
    created_at = Column(String(64), default=datetime.utcnow().isoformat)
