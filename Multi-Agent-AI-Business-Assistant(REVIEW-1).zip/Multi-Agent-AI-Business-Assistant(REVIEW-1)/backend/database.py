"""
backend/database.py
SQLite Database Configuration and Seeding Engine via SQLAlchemy.
Database file stored in database/enterprise.db.
"""

import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from backend.models import (
    Base,
    Department,
    Employee,
    LeaveRecord,
    Payroll,
    Reimbursement,
    EmailDraft,
    SupportTicket,
)

# Target database path: <project_root>/database/enterprise.db
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_DIR = os.path.join(BASE_DIR, "database")
os.makedirs(DB_DIR, exist_ok=True)
DB_PATH = os.path.join(DB_DIR, "enterprise.db")

SQLALCHEMY_DATABASE_URL = f"sqlite:///{DB_PATH}"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False}
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db():
    """FastAPI Dependency providing an isolated database session per request."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def seed_database(db):
    """Populates SQLite database with initial fictional enterprise benchmark records."""
    # 1. Seed Departments if empty
    if db.query(Department).count() == 0:
        departments = [
            Department(department_id="DEPT-HR", name="Human Resources", budget=250000.0, manager_name="Diana Prince"),
            Department(department_id="DEPT-FIN", name="Finance", budget=400000.0, manager_name="Arthur Dent"),
            Department(department_id="DEPT-ENG", name="Engineering", budget=1200000.0, manager_name="Marcus Brody"),
            Department(department_id="DEPT-QA", name="Quality Assurance", budget=300000.0, manager_name="Elena Rostova"),
            Department(department_id="DEPT-SUPP", name="Customer Support", budget=350000.0, manager_name="Sarah Connor"),
            Department(department_id="DEPT-MKT", name="Marketing", budget=500000.0, manager_name="Don Draper")
        ]
        db.add_all(departments)
        db.commit()

    # 2. Seed Employees if empty
    if db.query(Employee).count() == 0:
        employees = [
            Employee(
                employee_id="EMP-001",
                full_name="Alice Chen",
                email="alice.chen@enterprise.com",
                department="Engineering",
                role="Senior Software Engineer",
                base_salary=95000.0,
                joining_date="2022-03-15",
                status="Active"
            ),
            Employee(
                employee_id="EMP-002",
                full_name="Bob Smith",
                email="bob.smith@enterprise.com",
                department="Finance",
                role="Senior Financial Analyst",
                base_salary=82000.0,
                joining_date="2021-07-01",
                status="Active"
            ),
            Employee(
                employee_id="EMP-003",
                full_name="Carol Taylor",
                email="carol.taylor@enterprise.com",
                department="Quality Assurance",
                role="QA Automation Engineer",
                base_salary=70000.0,
                joining_date="2023-01-10",
                status="Active"
            ),
            Employee(
                employee_id="EMP-004",
                full_name="David Miller",
                email="david.miller@enterprise.com",
                department="Human Resources",
                role="HR Talent Specialist",
                base_salary=65000.0,
                joining_date="2020-11-20",
                status="Active"
            ),
            Employee(
                employee_id="EMP-005",
                full_name="Eva Zhang",
                email="eva.zhang@enterprise.com",
                department="Customer Support",
                role="Support Team Lead",
                base_salary=60000.0,
                joining_date="2023-05-04",
                status="Active"
            )
        ]
        db.add_all(employees)
        db.commit()

    # 3. Seed Leave Records
    if db.query(LeaveRecord).count() == 0:
        leaves = [
            LeaveRecord(
                record_id="LEV-201",
                employee_id="EMP-002",
                leave_type="Annual",
                start_date="2026-04-10",
                end_date="2026-04-12",
                days_requested=3,
                status="Approved",
                total_annual_allocated=24
            ),
            LeaveRecord(
                record_id="LEV-202",
                employee_id="EMP-002",
                leave_type="Sick",
                start_date="2026-08-15",
                end_date="2026-08-17",
                days_requested=3,
                status="Approved",
                total_annual_allocated=24
            ),
            LeaveRecord(
                record_id="LEV-203",
                employee_id="EMP-001",
                leave_type="Annual",
                start_date="2026-06-01",
                end_date="2026-06-05",
                days_requested=5,
                status="Approved",
                total_annual_allocated=24
            )
        ]
        db.add_all(leaves)
        db.commit()

    # 4. Seed Payroll Records
    if db.query(Payroll).count() == 0:
        payrolls = [
            Payroll(
                payroll_id="PAY-2026-10-001",
                employee_id="EMP-001",
                month="October",
                year=2026,
                base_salary=95000.0,
                allowances=20000.0,
                gross_salary=115000.0,
                tax_deductions=14000.0,
                provident_fund=9000.0,
                total_deductions=23000.0,
                net_pay=92000.0,
                payment_status="Paid"
            ),
            Payroll(
                payroll_id="PAY-2026-10-002",
                employee_id="EMP-002",
                month="October",
                year=2026,
                base_salary=82000.0,
                allowances=15000.0,
                gross_salary=97000.0,
                tax_deductions=11000.0,
                provident_fund=7000.0,
                total_deductions=18000.0,
                net_pay=79000.0,
                payment_status="Paid"
            )
        ]
        db.add_all(payrolls)
        db.commit()

    # 5. Seed Reimbursements
    if db.query(Reimbursement).count() == 0:
        reimbursements = [
            Reimbursement(
                claim_id="REIMB-101",
                employee_id="EMP-002",
                category="Travel",
                amount=220.0,
                submission_date="2026-10-05",
                status="Approved",
                notes="Client onsite visit transportation allowance within per diem cap"
            ),
            Reimbursement(
                claim_id="REIMB-104",
                employee_id="EMP-001",
                category="Hardware",
                amount=6200.0,
                submission_date="2026-10-18",
                status="Flagged",
                notes="Enterprise server replacement rack - exceeds automatic limit ($5000)"
            )
        ]
        db.add_all(reimbursements)
        db.commit()

    # 6. Seed Email Drafts
    if db.query(EmailDraft).count() == 0:
        drafts = [
            EmailDraft(
                draft_id="DRAFT-001",
                sender="assistant@enterprise.com",
                recipient="cto@enterprise.com",
                subject="Executive Approval Request: AI Workflow Automation Budget Allocation",
                body="Dear CTO,\n\nWe request approval for the initial budget of $45,000 for the AI Workflow Automation platform. Projected ROI payback period is 6 months with next steps scheduled for Q4.\n\nRegards,\nAI Project Team",
                related_incident=None,
                status="Draft"
            ),
            EmailDraft(
                draft_id="DRAFT-002",
                sender="ops@enterprise.com",
                recipient="executives@enterprise.com",
                subject="Post-Mortem Briefing: Resolution of Incident INC-8821",
                body="Incident INC-8821 was resolved in 34 minutes. Root cause was network switch firmware deadlock. Corrective actions underway.",
                related_incident="INC-8821",
                status="Ready for Dispatch"
            )
        ]
        db.add_all(drafts)
        db.commit()

    # 7. Seed Support Tickets
    if db.query(SupportTicket).count() == 0:
        tickets = [
            SupportTicket(
                ticket_id="TKT-901",
                customer_name="Acme Global Corp",
                customer_tier="Enterprise Gold",
                issue_description="Payment Gateway Timeout during checkout processing",
                priority="High",
                status="Open",
                assigned_team="Billing & Payments",
                resolution_time_hours=None,
                sla_met=1,
                csat_score=None
            ),
            SupportTicket(
                ticket_id="TKT-895",
                customer_name="Nova Tech Solutions",
                customer_tier="Standard",
                issue_description="SSL Certificate Renewal sync issue",
                priority="Medium",
                status="Resolved",
                assigned_team="Network Engineering",
                resolution_time_hours=1.4,
                sla_met=1,
                csat_score=5
            )
        ]
        db.add_all(tickets)
        db.commit()


def init_db():
    """Creates database tables and initializes initial dataset."""
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        seed_database(db)
    finally:
        db.close()


if __name__ == "__main__":
    init_db()
    print(f"Enterprise SQLite Database initialized successfully at: {DB_PATH}")
