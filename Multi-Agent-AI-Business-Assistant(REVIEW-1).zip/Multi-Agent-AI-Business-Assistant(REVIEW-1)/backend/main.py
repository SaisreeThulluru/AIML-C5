"""
backend/main.py
FastAPI Application Entry Point for Multi-Agent AI Business Assistant.
B.Tech Final Year Major Project - Team AIML-C05
Project Guide: Dr. Nuthi Raju
Module M1: Task Suite, Mock Systems & Metrics (Week 1 Foundation)
"""

from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from backend.database import init_db, get_db
from backend.models import Employee
from backend.routes.hr import router as hr_router
from backend.routes.tasks import router as tasks_router, load_tasks
from backend.schemas import HealthResponse


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan event handler to initialize database schema and seed data on launch."""
    init_db()
    yield


# Initialize FastAPI App with OpenAPI metadata
app = FastAPI(
    title="Multi-Agent AI Business Assistant - Enterprise API",
    description="""
### B.Tech Major Project &bull; Team AIML-C05
**Project Guide:** Dr. Nuthi Raju  
**Module M1:** Task Suite, Mock Systems & Metrics (Week 1 Foundation)

This service provides deterministic mock enterprise systems, employee directories,
leave balance tracking, and benchmark enterprise task management for evaluating
multi-agent workflow automation systems.
    """,
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# Enable CORS for browser access & frontend dashboards
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include sub-routers
app.include_router(hr_router)
app.include_router(tasks_router)


@app.get(
    "/",
    tags=["System"],
    summary="Root Service Metadata",
    description="Returns API service information, project team, and direct links to documentation."
)
def root():
    return {
        "project": "Multi-Agent AI Business Assistant for Intelligent Enterprise Workflow Automation",
        "team": "AIML-C05",
        "guide": "Dr. Nuthi Raju",
        "module": "M1 (Week 1 Foundation)",
        "status": "Operational",
        "documentation": "/docs",
        "endpoints": [
            "/employees",
            "/employees/{employee_id}",
            "/employees/{employee_id}/leave",
            "/tasks"
        ]
    }


@app.get(
    "/health",
    response_model=HealthResponse,
    tags=["System"],
    summary="Health check & telemetry",
    description="Validates SQLite connectivity and returns counts of seeded enterprise entities."
)
def health_check(db: Session = Depends(get_db)):
    emp_count = db.query(Employee).count()
    task_count = len(load_tasks())
    return HealthResponse(
        status="Healthy",
        database="SQLite (enterprise.db)",
        total_employees=emp_count,
        total_tasks=task_count
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="127.0.0.1", port=8000, reload=True)
