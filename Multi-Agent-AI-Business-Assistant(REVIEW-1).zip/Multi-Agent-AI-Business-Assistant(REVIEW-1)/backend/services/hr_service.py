"""
backend/services/hr_service.py
Core Business Logic and Service Layer for Mock HR System.
Handles database queries for employees, departments, and leave balance calculations.
Decoupled from web frameworks for clean architecture and rapid deterministic testing.
"""

from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import or_, func
from backend.models import Employee, LeaveRecord, Department


def get_employee_by_id(db: Session, employee_id: str) -> Optional[Employee]:
    """Retrieves a single employee by unique employee_id."""
    return db.query(Employee).filter(Employee.employee_id == employee_id).first()


def search_employees(db: Session, query: str) -> List[Employee]:
    """Searches employees by name, email, department, or role."""
    search_pattern = f"%{query}%"
    return db.query(Employee).filter(
        or_(
            Employee.full_name.ilike(search_pattern),
            Employee.email.ilike(search_pattern),
            Employee.department.ilike(search_pattern),
            Employee.role.ilike(search_pattern)
        )
    ).all()


def get_all_employees(
    db: Session,
    department: Optional[str] = None,
    search: Optional[str] = None
) -> List[Employee]:
    """Retrieves all employees with optional department filter and keyword search."""
    q = db.query(Employee)
    if department:
        q = q.filter(Employee.department.ilike(f"%{department}%"))
    if search:
        search_pattern = f"%{search}%"
        q = q.filter(
            or_(
                Employee.full_name.ilike(search_pattern),
                Employee.email.ilike(search_pattern),
                Employee.role.ilike(search_pattern)
            )
        )
    return q.all()


def get_employee_leave_balance(db: Session, employee_id: str) -> Optional[Dict[str, Any]]:
    """
    Computes total allocated, approved leaves taken, and remaining leave balance
    for a specific employee.
    """
    emp = get_employee_by_id(db, employee_id)
    if not emp:
        return None

    # Calculate total approved days requested
    approved_leaves = (
        db.query(func.coalesce(func.sum(LeaveRecord.days_requested), 0))
        .filter(
            LeaveRecord.employee_id == employee_id,
            LeaveRecord.status == "Approved"
        )
        .scalar()
    )

    total_allocated = 24  # Standard annual leave allocation
    latest_record = db.query(LeaveRecord).filter(LeaveRecord.employee_id == employee_id).first()
    if latest_record and latest_record.total_annual_allocated:
        total_allocated = latest_record.total_annual_allocated

    remaining = max(0, total_allocated - int(approved_leaves))

    return {
        "employee_id": emp.employee_id,
        "full_name": emp.full_name,
        "department": emp.department,
        "total_allocated": total_allocated,
        "approved_leaves_taken": int(approved_leaves),
        "remaining_leaves": int(remaining),
        "status": emp.status
    }
