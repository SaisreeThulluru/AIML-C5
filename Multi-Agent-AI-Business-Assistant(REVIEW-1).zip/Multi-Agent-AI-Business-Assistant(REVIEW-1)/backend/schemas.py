"""
backend/schemas.py
Pydantic Schemas for Strict Input/Output Validation & OpenAPI Documentation.
"""

from pydantic import BaseModel, ConfigDict
from typing import Optional, Dict, Any, List


class DepartmentResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    department_id: str
    name: str
    budget: float
    manager_name: str


class EmployeeResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    employee_id: str
    full_name: str
    email: str
    department: str
    role: str
    base_salary: float
    joining_date: str
    status: str


class LeaveBalanceResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    employee_id: str
    full_name: str
    department: str
    total_allocated: int
    approved_leaves_taken: int
    remaining_leaves: int
    status: str


class TaskItem(BaseModel):
    task_id: str
    department: str
    task_description: str
    input_parameters: Dict[str, Any]
    expected_output: Dict[str, Any]
    expected_outcome: str
    verification_criteria: Dict[str, Any]
    difficulty_level: str


class HealthResponse(BaseModel):
    status: str
    database: str
    total_employees: int
    total_tasks: int
