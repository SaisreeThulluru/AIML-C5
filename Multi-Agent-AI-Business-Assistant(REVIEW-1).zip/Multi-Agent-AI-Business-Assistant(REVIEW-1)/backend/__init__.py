"""
backend package
Multi-Agent AI Business Assistant
"""
