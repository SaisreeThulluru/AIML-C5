# Multi-Agent AI Business Assistant for Intelligent Enterprise Workflow Automation

**Final-Year Major Project &bull; Team AIML-C05**  
**Project Guide:** Dr. Nuthi Raju  
**Module:** M1 – Task Suite, Mock Systems & Metrics (Week 1 Foundation)

---

## 📌 Project Overview
Modern enterprises execute thousands of cross-departmental workflows daily involving Human Resources, Finance & Payroll, Software Engineering, Customer Support, Analytics, and Internal Communications. This project develops an autonomous, multi-agent AI framework capable of end-to-end business workflow execution, tool invocation, and verifiable task completion.

Module **M1 (Weeks 1–3)** builds the rigorous evaluation harness, deterministic mock enterprise environments, cross-departmental task suites, and ground-truth verification mechanisms inspired by state-of-the-art agent evaluation benchmarks (**$\tau$-bench** and **WorkBench**).

---

## 🎯 Week 1 Foundation Scope
Week 1 establishes the deterministic system foundation:
1. **Standardized Project Structure:** Clean separation of backend REST services, SQLite mock persistence, evaluation checkers, test suites, and academic documentation.
2. **Enterprise Task Suite (15 Benchmark Tasks):** Cross-departmental task definitions across 6 domains with strictly checkable expected outcomes and input schemas.
3. **Enterprise Database (`database/enterprise.db`):** Relational schema covering Employees, Departments, Leave Records, Payroll, Reimbursements, Email Drafts, and Support Tickets.
4. **Mock HR Service & FastAPI Backend:** High-performance RESTful API endpoints with Pydantic validation, SQLite ORM queries via SQLAlchemy, and auto-generated Swagger UI (`/docs`).
5. **Deterministic Ground-Truth Verification:** Programmatic evaluation harness checking system state and assertions against expected criteria.
6. **Comprehensive Automated Testing:** `pytest` test suites validating database integrity, API routes, task dataset parsing, and verification logic.

---

## 🗂️ Project Directory Architecture
```text
Multi-Agent-AI-Business-Assistant/
├── backend/
│   ├── main.py                  # FastAPI application entrypoint & OpenAPI documentation
│   ├── database.py              # SQLite engine, session management, and seed loader
│   ├── models.py                # SQLAlchemy ORM declarative models
│   ├── schemas.py               # Pydantic validation models for request/response payloads
│   └── routes/
│       ├── hr.py                # Mock HR service routes (employees, leave balances)
│       └── tasks.py             # Enterprise task suite discovery endpoints
├── database/
│   └── enterprise.db            # SQLite relational mock database
├── datasets/
│   └── sample_tasks.json        # 15 structured cross-department enterprise tasks
├── evaluation/
│   └── ground_truth.py          # Deterministic verification engine (pass/fail assertions)
├── tests/
│   ├── test_database.py         # Pytest suite for database schemas & seeding
│   ├── test_hr.py               # Pytest suite for HR service functions & endpoints
│   ├── test_tasks.py            # Pytest suite for task dataset format & schema
│   └── test_ground_truth.py     # Pytest suite for verification checker logic
├── research/
│   └── literature_review.md     # Literature review: τ-bench (Berkeley) & WorkBench (Stanford)
├── docs/
│   ├── architecture.md          # System architecture, schemas, and verification workflow
│   └── week1_progress.md        # Week 1 deliverables, test results & Week 2 roadmap
├── requirements.txt             # Project dependencies (FastAPI, SQLAlchemy, Pydantic, Pytest)
└── README.md                    # Project documentation
```

---

## ⚙️ Quickstart & Local Setup

### 1. Prerequisites
- Python 3.10+
- Windows PowerShell / Linux Terminal

### 2. Virtual Environment Setup
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

### 3. Install Dependencies
```powershell
pip install -r requirements.txt
```

### 4. Initialize Database
```powershell
python -c "from backend.database import init_db; init_db()"
```

### 5. Launch FastAPI Backend
```powershell
uvicorn backend.main:app --reload --port 8000
```
Open interactive Swagger documentation at: **http://127.0.0.1:8000/docs**

### 6. Run Automated Tests
```powershell
pytest -v
```

---

## 📊 Module M1 Roadmap
- [x] **Week 1:** Core project foundation, 15 enterprise tasks, SQLite enterprise schemas, mock HR service, FastAPI REST endpoints, deterministic ground-truth verification, pytest test harness, literature review, and architecture specifications.
- [ ] **Week 2:** Expansion to 35+ tasks, mock Finance/Payroll sandbox, sandbox email engine, mock SQL warehouse, and automated multi-step state verification.
- [ ] **Week 3:** Complete 50–60 cross-department tasks, ticketing system mock integration, evaluation harness with pass@k / success rate metrics, and baseline agent benchmarking.
