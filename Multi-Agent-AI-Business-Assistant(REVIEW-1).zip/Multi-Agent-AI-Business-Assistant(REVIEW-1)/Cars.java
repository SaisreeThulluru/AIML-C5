import java.util.Scanner;

public class Cars {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        if (scanner.hasNextInt()) {
            int n = scanner.nextInt();
            int count = 0;
            int minSpeed = Integer.MAX_VALUE;
            
            for (int i = 0; i < n; i++) {
                int speed = scanner.nextInt();
                if (speed <= minSpeed) {
                    count++;
                    minSpeed = speed;
                }
            }
            System.out.println(count);
        }
        scanner.close();
    }
}
