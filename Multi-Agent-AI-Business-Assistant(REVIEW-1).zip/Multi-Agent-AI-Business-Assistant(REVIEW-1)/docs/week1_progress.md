# Week 1 Progress Report: Module M1 Foundation

**Project Title:** Multi-Agent AI Business Assistant for Intelligent Enterprise Workflow Automation  
**Team:** AIML-C05  
**Project Guide:** Dr. Nuthi Raju  
**Course:** B.Tech Major Project (Final Year)  
**Reporting Period:** Week 1 of Module M1 (Task Suite, Mock Systems & Metrics)  
**Submission Date:** November 2026  

---

## 1. Week 1 Objectives

The primary objective for Week 1 was to establish the deterministic foundation for Module M1 without attempting to build the entire 3-week module in a single week. Specifically:
1. Initialize the Python project architecture, virtual environment, dependencies, and version control.
2. Formulate an initial benchmark suite of 15 realistic cross-department enterprise tasks with checkable outcomes.
3. Design and seed an SQLite relational enterprise database covering 7 key domains.
4. Implement the core HR mock service and FastAPI backend with interactive OpenAPI documentation.
5. Build a deterministic ground-truth verification engine inspired by $\tau$-bench and WorkBench.
6. Establish an automated `pytest` test harness and verify 100% pass rates.
7. Conduct a formal literature review on $\tau$-bench (UC Berkeley) and WorkBench (Stanford).
8. Author system architecture specifications and this Week 1 progress report.

---

## 2. Technologies Used

- **Programming Language:** Python 3.10.11
- **Web API Framework:** FastAPI (v0.162.0)
- **ASGI Web Server:** Uvicorn (v0.54.0)
- **Database Engine & ORM:** SQLite 3 & SQLAlchemy (v2.0.57)
- **Data Validation & Serialization:** Pydantic (v2.12.5)
- **Automated Testing Harness:** Pytest (v7.0.0)
- **Version Control:** Git & GitHub

---

## 3. Components Implemented

1. **Standardized Project Architecture:** Clean separation of concerns between API routers, business service layers, database models, datasets, verification engines, and test suites.
2. **Enterprise Benchmark Task Suite:** 15 fully specified tasks across 6 departments with inputs, expected outputs, outcomes, and difficulty levels.
3. **Enterprise Mock Relational Database (`database/enterprise.db`):** 7 populated tables:
   - `departments` (6 records)
   - `employees` (5 records)
   - `leave_records` (3 records)
   - `payroll` (2 records)
   - `reimbursements` (2 records)
   - `email_drafts` (2 records)
   - `support_tickets` (2 records)
4. **Mock HR Service Layer (`backend/services/hr_service.py`):** Pure Python business logic providing employee profile lookup, full-text search, department filtering, and leave balance calculation.
5. **FastAPI REST Backend (`backend/main.py`):**
   - `GET /` — Service metadata and root status.
   - `GET /health` — Database connectivity check and entity telemetry.
   - `GET /employees` — List/search employees with optional query filters.
   - `GET /employees/{employee_id}` — Single employee profile retrieval with 404 handling.
   - `GET /employees/{employee_id}/leave` — Dynamic leave balance calculation.
   - `GET /tasks` — Benchmark task suite retrieval with department & difficulty filters.
   - `GET /tasks/{task_id}` — Single task criteria lookup.
   - Interactive Swagger UI at `http://127.0.0.1:8000/docs`.
6. **Deterministic Ground-Truth Verifier (`evaluation/ground_truth.py`):** Object-oriented verification engine asserting database state, attribute matches, and mathematical leave deductions.
7. **Automated Testing Suite:** 4 pytest test suites (`tests/test_database.py`, `tests/test_hr.py`, `tests/test_tasks.py`, `tests/test_ground_truth.py`).

---

## 4. Files Created / Modified

| File / Artifact Path | Architectural Role & Summary |
| :--- | :--- |
| `backend/models.py` | SQLAlchemy ORM declarative models for all 7 enterprise entities. |
| `backend/database.py` | SQLite connection engine, session factory, and database seeder. |
| `backend/schemas.py` | Pydantic validation models for requests, responses, and tasks. |
| `backend/services/hr_service.py` | Framework-agnostic business logic for employee and leave queries. |
| `backend/routes/hr.py` | FastAPI HTTP controllers for HR endpoints. |
| `backend/routes/tasks.py` | FastAPI HTTP controllers for benchmark task retrieval. |
| `backend/main.py` | FastAPI application entrypoint with lifespan event handlers and CORS. |
| `database/enterprise.db` | Working SQLite relational database populated with seed records. |
| `datasets/sample_tasks.json` | 15 cross-department benchmark tasks formatted in JSON. |
| `evaluation/ground_truth.py` | Deterministic verification engine returning PASS/FAIL reports. |
| `tests/conftest.py` | Pytest session fixtures and transactional DB session injection. |
| `tests/test_database.py` | 3 test cases validating schema tables, row counts, and ORM joins. |
| `tests/test_hr.py` | 7 test cases validating employee search, retrieval, and leave balance. |
| `tests/test_tasks.py` | 4 test cases validating task count, schema keys, and department scope. |
| `tests/test_ground_truth.py` | 7 test cases validating pass/fail verification assertions. |
| `research/literature_review.md` | Academic reading notes on $\tau$-bench (Berkeley) and WorkBench (Stanford). |
| `docs/architecture.md` | Technical specifications, ER diagram, and Mermaid workflows. |
| `docs/week1_progress.md` | Official Week 1 progress report. |
| `requirements.txt` | Pinned project dependencies. |
| `README.md` | Project overview, setup instructions, and evaluation roadmap. |
| `pytest.ini` | Pytest configuration file. |

---

## 5. Actual Testing Performed

1. **Database Schema & Seeding Verification:** Verified that all 7 tables exist and record counts match expected quantities.
2. **HR Business Logic Testing:** Tested employee retrieval by ID, keyword search across name and role, and mathematical leave balance calculations (`24 - 6 = 18`).
3. **Dataset Schema Conformance:** Verified all 15 tasks in `sample_tasks.json` contain all 8 mandatory attributes and span all 6 departments.
4. **Deterministic Ground-Truth Assertions:** Tested positive assertions (existing employee, correct details, correct leave balance) and negative assertions (non-existent employee, incorrect details).
5. **Full Pytest Execution:** Executed `pytest tests/ -v` across all test modules.

---

## 6. Test Results

**Command Executed:**
```powershell
python -m pytest tests/ -v
```

**Verbatim Pytest Output:**
```text
============================= test session starts =============================
platform win32 -- Python 3.10.11, pytest-7.0.0, pluggy-1.6.0 -- C:\Users\SAI SREE\AppData\Local\Programs\Python\Python310\python.exe
cachedir: .pytest_cache
rootdir: C:\Users\SAI SREE\Documents\antigravity\zealous-meitner, configfile: pytest.ini
collecting ... collected 21 items

tests/test_database.py::test_tables_exist PASSED                         [  4%]
tests/test_database.py::test_seeded_record_counts PASSED                 [  9%]
tests/test_database.py::test_employee_relationships PASSED               [ 14%]
tests/test_ground_truth.py::test_verify_employee_existence_pass PASSED   [ 19%]
tests/test_ground_truth.py::test_verify_employee_existence_fail PASSED   [ 23%]
tests/test_ground_truth.py::test_verify_employee_details_pass PASSED     [ 28%]
tests/test_ground_truth.py::test_verify_employee_details_fail PASSED     [ 33%]
tests/test_ground_truth.py::test_verify_leave_balance_pass PASSED        [ 38%]
tests/test_ground_truth.py::test_verify_leave_balance_fail PASSED        [ 42%]
tests/test_ground_truth.py::test_verify_task_outcome_pass PASSED         [ 47%]
tests/test_hr.py::test_get_all_employees PASSED                          [ 52%]
tests/test_hr.py::test_get_all_employees_with_department_filter PASSED   [ 57%]
tests/test_hr.py::test_get_employee_by_id PASSED                         [ 61%]
tests/test_hr.py::test_get_employee_by_invalid_id PASSED                 [ 66%]
tests/test_hr.py::test_search_employees PASSED                           [ 71%]
tests/test_hr.py::test_leave_balance_calculation PASSED                  [ 76%]
tests/test_hr.py::test_leave_balance_invalid_employee PASSED             [ 80%]
tests/test_tasks.py::test_task_count PASSED                              [ 85%]
tests/test_tasks.py::test_all_six_departments_covered PASSED             [ 90%]
tests/test_tasks.py::test_mandatory_task_fields PASSED                   [ 95%]
tests/test_tasks.py::test_difficulty_levels PASSED                       [100%]

============================= 21 passed in 0.23s ==============================
```

**Outcome:** 21 passed, 0 failed, 0 warnings. 100% test pass rate achieved in 0.23 seconds.

---

## 7. Screenshots / Evidence to Collect for Review

During the Week 1 review with Dr. Nuthi Raju, capture and present:
1. **VS Code Explorer Tree:** Showing clean folder structure (`backend/`, `database/`, `datasets/`, `evaluation/`, `tests/`, `research/`, `docs/`).
2. **Terminal Pytest Result:** Screenshot of `python -m pytest tests/ -v` displaying 21 passed tests in green.
3. **Interactive Swagger UI:** Browser screenshot of `http://127.0.0.1:8000/docs` showing GET `/employees`, GET `/employees/{employee_id}`, GET `/employees/{employee_id}/leave`, and GET `/tasks`.
4. **SQLite Database Inspection:** Screenshot of SQLite table viewer or terminal query showing the `employees` and `leave_records` tables.
5. **Ground Truth Verification Output:** Terminal screenshot of `python -m evaluation.ground_truth` displaying `[PASS]` and `[FAIL]` reports.
6. **Git Commit History:** Screenshot of `git log --oneline` demonstrating structured incremental commits.

---

## 8. Incomplete Work (Transparently Documented)

As per official project scheduling, Module M1 spans Weeks 1 to 3. The following components are intentionally scheduled for subsequent weeks and are **not** claimed as completed in Week 1:
- **Submodule 1.1 Extension:** Expanding task dataset from 15 tasks to the final 40–60 cross-department benchmark tasks (Scheduled for Weeks 2 & 3).
- **Submodule 1.2 Extension:** Mock Finance/Payroll sandbox with tax calculator, toy SQL warehouse engine, sandbox email dispatch simulator, and support ticket lifecycle updates (Scheduled for Week 2).
- **Submodule 1.4 Extension:** Automated evaluation harness with $\text{pass}^k$ consistency metrics and baseline multi-agent benchmarking (Scheduled for Week 3).
- **Multi-Agent Orchestration:** Coordinator agent, intent classification, and LLM-powered domain agents (Module M2, Weeks 4+).

---

## 9. Week 2 Action Plan

1. **Expand Task Suite:** Add 20 additional enterprise tasks (targeting 35 total) covering multi-step finance approvals, SQL warehouse joins, and email notifications.
2. **Build Mock Finance/Payroll Sandbox:** Implement `/finance/payroll/calculate` and `/finance/reimbursements/audit` API routes.
3. **Build Mock Email Dispatch Engine:** Implement mock SMTP inbox with sent draft validation.
4. **Build Toy SQL Warehouse:** Implement read-only aggregate queries over synthetic sales and inventory databases.
5. **Multi-Step State Ground-Truth Checkers:** Implement state verification across sequential dependent actions (e.g. Employee Created $\rightarrow$ Leave Allocated $\rightarrow$ Welcome Email Drafted).
