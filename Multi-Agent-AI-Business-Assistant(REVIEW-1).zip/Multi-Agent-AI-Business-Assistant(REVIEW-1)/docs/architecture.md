# System Architecture: Multi-Agent AI Business Assistant

**Project Title:** Multi-Agent AI Business Assistant for Intelligent Enterprise Workflow Automation  
**Team:** AIML-C05  
**Project Guide:** Dr. Nuthi Raju  
**Document:** System Architecture & Technical Specifications  
**Module:** M1 (Week 1 Foundation)  

---

## 1. Project Overview & Architectural Vision

Modern enterprise workflows involve distributed operations across disparate departmental systems—such as Human Resources information systems (HRIS), Enterprise Resource Planning (ERP), payroll ledgers, issue trackers, email servers, and analytical data warehouses. When employees coordinate cross-functional tasks (e.g. employee onboarding, vendor reimbursement, incident post-mortems), substantial human overhead is expended navigating heterogeneous software interfaces and manual data re-entry.

The goal of this project is to develop an autonomous **Multi-Agent AI Business Assistant** that interprets natural language enterprise commands, coordinates domain-specialist agents, invokes verified backend APIs, and deterministically executes multi-step workflows with comprehensive audit logging.

Module **M1 (Weeks 1–3)** builds the foundational bedrock:
- A standardized **cross-departmental benchmark task suite**.
- Deterministic **mock enterprise systems** (SQLite & FastAPI).
- Automated **ground-truth verification checkers**.
- An academic evaluation harness modeled after **$\tau$-bench** and **WorkBench**.

---

## 2. Enterprise Departmental Taxonomy

The system models six essential enterprise business domains:

```mermaid
graph TD
    Enterprise[Enterprise Assistant Scope] --> HR[1. Human Resources]
    Enterprise --> FIN[2. Finance & Payroll]
    Enterprise --> ENG[3. Software Engineering]
    Enterprise --> MAIL[4. Email Communication]
    Enterprise --> DATA[5. Data Analytics]
    Enterprise --> SUPP[6. Customer Support]

    HR --> HR_Tools[Employee Directory, Leave Allocation, Dept Transfers]
    FIN --> FIN_Tools[Payroll Engine, Tax Calculations, Reimbursement Audit]
    ENG --> ENG_Tools[Crash Log Triage, Commit Validation, CI/CD Status]
    MAIL --> MAIL_Tools[Executive Drafting, Retrospectives, Meeting Invites]
    DATA --> DATA_Tools[SQL Warehousing, Revenue Aggregation, Stock Alerts]
    SUPP --> SUPP_Tools[Ticketing SLA Triage, CSAT Tracking, Queue Routing]
```

---

## 3. High-Level System Architecture (Week 1 Foundation)

```mermaid
flowchart TD
    subgraph Client_Layer ["Client & Interface Layer"]
        User([Enterprise User / Evaluator])
        Swagger[OpenAPI Swagger UI /docs]
        TestRunner[Automated Pytest Harness]
    end

    subgraph API_Layer ["FastAPI Service Layer (backend/main.py)"]
        Router_HR["HR Router (/employees, /leave)"]
        Router_Tasks["Tasks Router (/tasks)"]
        PydanticSchemas["Pydantic Validation & Serialization"]
    end

    subgraph Service_Layer ["Business Logic & Service Layer"]
        HRService["HR Service (backend/services/hr_service.py)"]
        TaskLoader["Task Suite Parser (datasets/sample_tasks.json)"]
    end

    subgraph Persistence_Layer ["Relational Persistence Layer (SQLite)"]
        Engine["SQLAlchemy Engine (database/enterprise.db)"]
        Tables[("7 Enterprise Tables:
        - departments
        - employees
        - leave_records
        - payroll
        - reimbursements
        - email_drafts
        - support_tickets")]
    end

    subgraph Evaluation_Layer ["Verification Engine (evaluation/ground_truth.py)"]
        Verifier["GroundTruthVerifier"]
        StateCheck["Database State Comparator"]
        OutputCheck["Rubric Assertion Engine"]
        Report[("Verification Report: PASS / FAIL + Telemetry")]
    end

    User -->|HTTP Requests| Swagger
    Swagger --> Router_HR
    Swagger --> Router_Tasks
    TestRunner --> Router_HR
    TestRunner --> Verifier

    Router_HR --> PydanticSchemas
    Router_Tasks --> PydanticSchemas

    PydanticSchemas --> HRService
    PydanticSchemas --> TaskLoader

    HRService --> Engine
    Engine --> Tables

    Verifier --> StateCheck
    Verifier --> OutputCheck
    StateCheck --> Tables
    OutputCheck --> TaskLoader
    StateCheck --> Report
    OutputCheck --> Report
```

---

## 4. Mock Database Relational Schema

The enterprise database is hosted locally at `database/enterprise.db` managed via SQLAlchemy Declarative ORM (`backend/models.py`).

```mermaid
erDiagram
    DEPARTMENTS ||--o{ EMPLOYEES : "employs"
    EMPLOYEES ||--o{ LEAVE_RECORDS : "files"
    EMPLOYEES ||--o{ PAYROLL : "receives"
    EMPLOYEES ||--o{ REIMBURSEMENTS : "submits"

    DEPARTMENTS {
        int id PK
        string department_id UK
        string name UK
        float budget
        string manager_name
    }

    EMPLOYEES {
        int id PK
        string employee_id UK
        string full_name
        string email UK
        string department FK
        string role
        float base_salary
        string joining_date
        string status
    }

    LEAVE_RECORDS {
        int id PK
        string record_id UK
        string employee_id FK
        string leave_type
        string start_date
        string end_date
        int days_requested
        string status
        int total_annual_allocated
    }

    PAYROLL {
        int id PK
        string payroll_id UK
        string employee_id FK
        string month
        int year
        float gross_salary
        float total_deductions
        float net_pay
        string payment_status
    }

    REIMBURSEMENTS {
        int id PK
        string claim_id UK
        string employee_id FK
        string category
        float amount
        string submission_date
        string status
        text notes
    }

    EMAIL_DRAFTS {
        int id PK
        string draft_id UK
        string sender
        string recipient
        string subject
        text body
        string related_incident
        string status
    }

    SUPPORT_TICKETS {
        int id PK
        string ticket_id UK
        string customer_name
        string customer_tier
        string priority
        string status
        string assigned_team
        float resolution_time_hours
        int sla_met
        int csat_score
    }
```

---

## 5. Task Execution & Ground-Truth Verification Workflow

Adopting the evaluation paradigms from $\tau$-bench and WorkBench, our ground-truth verification workflow operates deterministically without relying on subjective LLM evaluations:

```mermaid
sequenceDiagram
    autonumber
    actor Evaluator as Evaluator / Pytest
    participant Suite as Task Suite (sample_tasks.json)
    participant Agent as Candidate Agent / API
    participant DB as SQLite (enterprise.db)
    participant Verifier as GroundTruthVerifier

    Evaluator->>Suite: Load Task Specification (e.g. TASK-HR-002)
    Suite-->>Evaluator: Input: {employee_id: "EMP-002"}
    Evaluator->>Agent: Execute Task with Input Parameters
    Agent->>DB: Query or Mutate Database State
    Agent-->>Evaluator: Return Candidate Output Payload
    
    Evaluator->>Verifier: Verify(task_id, Candidate Output)
    Verifier->>DB: Inspect Database Records & Computations
    Verifier->>Suite: Compare against Expected Criteria
    Verifier-->>Evaluator: Return VerificationResult(PASS/FAIL, Details)
```

### Deterministic Calculation Example:
For leave balance verification (`TASK-HR-002`):
$$\text{Remaining Leaves} = \text{Total Allocated Quota} - \sum_{\text{Approved}} \text{Days Requested}$$
- Base allocation = 24 days
- Approved leaves taken by EMP-002 = 3 days (April) + 3 days (August) = 6 days
- Calculated remaining leaves = 18 days
- The verifier performs strict numeric equality assertions; any variance immediately triggers an automated `FAIL` with diagnostic telemetry.

---

## 6. Future Multi-Agent Integration Roadmap (Weeks 2–4)

In subsequent project phases, the system will evolve into a complete multi-agent collaborative framework:

```mermaid
flowchart TD
    UserPrompt([User Enterprise Request]) --> Coordinator[Coordinator Orchestrator Agent]
    Coordinator --> IntentClassifier[Intent Classifier & Parameter Extractor]
    
    IntentClassifier --> Dispatcher{Agent Dispatcher}
    
    Dispatcher -->|HR Inquiries & Transfers| HRAgent[HR Specialist Agent]
    Dispatcher -->|Salary & Expense Audits| FinAgent[Finance Specialist Agent]
    Dispatcher -->|Log Analysis & Code Triage| CodeAgent[Software Engineering Agent]
    Dispatcher -->|Formal Communications| MailAgent[Email Communication Agent]
    Dispatcher -->|SQL & Reporting| DataAgent[Data Analytics Agent]
    Dispatcher -->|Customer Issues & Tickets| SupportAgent[Customer Support Agent]

    HRAgent --> ToolBus[Enterprise Tool Bus / API Router]
    FinAgent --> ToolBus
    CodeAgent --> ToolBus
    MailAgent --> ToolBus
    DataAgent --> ToolBus
    SupportAgent --> ToolBus

    ToolBus --> FastAPIServices[FastAPI Mock Systems]
    FastAPIServices --> SQLiteDB[(SQLite Relational DB)]
    
    SQLiteDB --> VerifierEngine[Automated Ground-Truth Verifier]
```

This modular architecture guarantees that agent performance can be independently measured against the benchmark suite established during Week 1.
