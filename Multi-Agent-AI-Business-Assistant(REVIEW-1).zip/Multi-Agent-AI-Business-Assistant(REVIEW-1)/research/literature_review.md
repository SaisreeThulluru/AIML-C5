# Research Literature Review: Benchmarking Multi-Agent Enterprise Workflows

**Project Title:** Multi-Agent AI Business Assistant for Intelligent Enterprise Workflow Automation  
**Team:** AIML-C05  
**Project Guide:** Dr. Nuthi Raju  
**Course:** B.Tech Major Project &bull; Module M1 (Task Suite, Mock Systems & Metrics)  
**Date:** November 2026  

---

## 1. Introduction & Context

Enterprise automated systems require AI agents to execute non-trivial multi-step tasks across real-world enterprise databases, APIs, and domain-specific policies. Traditional LLM benchmarks (such as MMLU or HumanEval) focus on static question answering or isolated code generation. However, they fail to evaluate:
1. Dynamic environment interactions (reading and modifying enterprise databases).
2. Adherence to strict enterprise compliance rules (e.g. per-diem caps, privacy controls, authorization levels).
3. Complex multi-turn user-agent dialogues where user intent is ambiguous or incomplete.
4. Deterministic ground-truth outcome verification.

To address these challenges in Module M1, we analyze two foundational benchmarking papers: **$\tau$-bench** (UC Berkeley) and **WorkBench** (Stanford University).

---

## 2. Paper 1: $\tau$-bench ($\tau$-bench: A Benchmark for Tool-Agent-User Interaction in Real-World Environments)

- **Authors:** Shunyu Liu, Noah Shinn, Richard Ann, et al. (UC Berkeley & Princeton University, 2024)
- **Paper Link:** [arXiv:2406.12045](https://arxiv.org/abs/2406.12045)

### 2.1 Research Objective
The core objective of $\tau$-bench is to evaluate conversational AI agents in dynamic, realistic environments where tasks involve both **user-agent communication** and **tool/database API calls**. The authors argue that existing benchmarks fail because they evaluate either pure conversational ability without environment side-effects, or single-step tool calling without multi-turn user constraints.

### 2.2 Evaluation Approach
1. **Simulated Dynamic Environments:** The benchmark models two real-world domains:
   - **Retail (e-commerce):** Customer support, product returns, address changes, order cancellations.
   - **Airline:** Reservation modifications, flight rebooking, luggage allowance upgrades.
2. **Deterministic Mock Databases:** Built with mock relational databases and strict API endpoints (e.g., flight databases, inventory catalogs, user accounts).
3. **User Simulator:** A dedicated LLM acts as the human user with private latent preferences and goals.
4. **Environment State Verification:** The evaluation does not rely on subjective LLM-as-a-judge text comparison. Instead, it inspects the final database state to verify if the correct rows were inserted, updated, or deleted according to the ground-truth goal.
5. **Metric ($\text{pass}^k$):** Evaluates agent consistency over $k$ independent runs, requiring an agent to succeed on all trials to measure reliability.

### 2.3 Main Ideas Relevant to Our Major Project
- **Domain-Specific Policy Rules:** In $\tau$-bench, agents are provided with explicit policy rules (e.g., "Non-refundable tickets cannot be cancelled within 24 hours of flight"). In our project, enterprise policies (e.g., "Reimbursements exceeding $5,000 require executive escalation", "Leave requests cannot exceed annual quota") dictate agent behavior.
- **State-Based Ground Truth:** Evaluating agent actions by querying the backend database state rather than parsing conversational text.
- **Separation of API Execution from Chat Dialogue:** Distinct tool interfaces where actions directly alter database state.

### 2.4 How We Adopt $\tau$-bench Concepts into Our System
1. **Deterministic Mock Systems (Submodule 1.2):** We adopt $\tau$-bench’s architecture by building SQLite mock systems (`enterprise.db`) with relational schemas for Employees, Leave, Payroll, Reimbursements, and Tickets.
2. **Environment State Inspection (Submodule 1.3):** In `evaluation/ground_truth.py`, we implement deterministic checkers that query SQLite directly to confirm whether candidate agent actions produced the correct side-effects (e.g. confirming `leaves_remaining = total - sum(approved)`).
3. **Consistency Metric Readiness (Submodule 1.4):** In Week 3, we will adopt the pass@k evaluation harness to benchmark agent consistency across multiple trials.

---

## 3. Paper 2: WorkBench (Benchmarking Multi-Task Enterprise Agents with Complex Workflows)

- **Authors:** Tianbao Xie, Chen Henry Wu, Peng Shi, et al. (Stanford University & The Ohio State University, 2024)
- **Paper Link:** [arXiv:2405.00823](https://arxiv.org/abs/2405.00823)

### 3.1 Research Objective
WorkBench was developed to evaluate enterprise-grade AI agents across complex, multi-turn, multi-tool enterprise workflows. The objective is to measure how effectively agents can autonomously plan, retrieve cross-department data, invoke internal tools, and resolve realistic workplace tasks without human intervention.

### 3.2 Evaluation Approach
1. **Broad Cross-Department Task Coverage:** Features tasks spanning HR, Finance, Customer Management, IT Operations, and Software Development.
2. **Multi-Tool Composition:** Tasks require calling sequences of heterogeneous tools (e.g., SQL queries, email drafting, API requests, calculation scripts).
3. **Fine-Grained Rubrics:** Each task has structured criteria detailing:
   - Mandatory prerequisite steps.
   - Exact input arguments for intermediate tool invocations.
   - Ground-truth output schema and numeric tolerance bounds.
4. **Error Diagnosis Pipeline:** WorkBench classifies failures into distinct categories:
   - Tool call failure (invalid parameters or syntax).
   - Planning error (wrong sequence of agent actions).
   - Constraint violation (breaching enterprise policies).
   - Hallucination (inventing data not found in the database).

### 3.3 Main Ideas Relevant to Our Major Project
- **Structured Task Specifications:** Every benchmark task is represented as a machine-readable JSON object specifying input parameters, expected output, and verification criteria.
- **Categorization by Department and Difficulty:** WorkBench stratifies tasks across departments and difficulty tiers (Easy, Medium, Hard) to systematically identify model degradation boundaries.
- **Automated Verification Harness:** Uses deterministic scripts to grade agent performance automatically.

### 3.4 How We Adopt WorkBench Concepts into Our System
1. **Standardized Task Suite Schema (Submodule 1.1):** In `datasets/sample_tasks.json`, we adopted WorkBench's structured schema format with 8 required fields:
   - `task_id`, `department`, `task_description`, `input_parameters`, `expected_output`, `expected_outcome`, `verification_criteria`, `difficulty_level`.
2. **Cross-Departmental Scope:** Spanning all 6 core enterprise departments (HR, Finance, Engineering, Email, Analytics, Support).
3. **Deterministic Evaluation Checkers:** In `evaluation/ground_truth.py`, we adopted WorkBench's fine-grained assertion engine, returning structured PASS/FAIL outcomes accompanied by granular diagnostic explanations.

---

## 4. Synthesis & Methodology Comparison

| Dimension | Standard LLM Evaluation (MMLU / GSM8K) | $\tau$-bench | WorkBench | Our Project (Module M1) |
| :--- | :--- | :--- | :--- | :--- |
| **Domain** | Academic trivia / Math / Coding | Retail & Airline Services | Broad Enterprise Operations | Multi-Department Enterprise Automation |
| **Environment** | Static prompt / text | Dynamic relational DB + API | Multi-tool enterprise sandbox | SQLite mock database + FastAPI endpoints |
| **Verification** | Exact string / Regex match | Final environment state check | Rubric & execution state checking | Deterministic ground-truth DB assertions |
| **Evaluation Bias** | Susceptible to data contamination | Low (dynamic environment states) | Low (multi-step workflow rubrics) | Zero (deterministic SQLite checks) |
| **Metrics** | Accuracy (%) | $\text{pass}^k$ consistency | Task Success Rate & Error Breakdown | Verification Pass Rate, Latency, Accuracy |

---

## 5. Summary & Week 1 Conclusion

Studying $\tau$-bench and WorkBench informed our Week 1 implementation:
1. We avoided subjective "LLM-as-a-judge" grading in favor of deterministic database state verification.
2. We established a standardized 15-task benchmark dataset (`datasets/sample_tasks.json`) inspired by WorkBench's rubric model.
3. We architected our SQLite database (`database/enterprise.db`) to mirror the relational state inspection patterns validated in $\tau$-bench.
4. This foundation ensures that when we connect autonomous agents in Weeks 2–4, our evaluation results will be academically sound, reproducible, and verifiable.
