/**
 * OmniAgent Enterprise | Frontend Controller
 * Multi-Agent AI Business Assistant
 */

document.addEventListener("DOMContentLoaded", () => {
  // --- DOM Elements ---
  const navItems = document.querySelectorAll(".nav-item");
  const viewPanels = document.querySelectorAll(".view-panel");
  const currentViewTitle = document.getElementById("current-view-title");
  const currentViewDesc = document.getElementById("current-view-desc");

  // Chat Elements
  const chatForm = document.getElementById("chat-form");
  const userInput = document.getElementById("user-input");
  const chatStream = document.getElementById("chat-stream");
  const sendBtn = document.getElementById("send-btn");
  const clearInputBtn = document.getElementById("clear-input-btn");
  const promptChips = document.querySelectorAll(".prompt-chip");

  // Dashboard & Logs Elements
  const statTotalRequests = document.getElementById("stat-total-requests");
  const statSuccessRate = document.getElementById("stat-success-rate");
  const statSuccessfulCount = document.getElementById("stat-successful-count");
  const statAvgLatency = document.getElementById("stat-avg-latency");
  const agentDistributionContainer = document.getElementById("agent-distribution-container");
  const recentActivityContainer = document.getElementById("recent-activity-container");
  const agentStatusTableBody = document.getElementById("agent-status-table-body");
  const refreshDataBtn = document.getElementById("refresh-data-btn");

  const auditLogsTbody = document.getElementById("audit-logs-tbody");
  const logSearchInput = document.getElementById("log-search-input");
  const refreshLogsBtn = document.getElementById("refresh-logs-btn");
  const agentsCardsGrid = document.getElementById("agents-cards-grid");

  // Modal Elements
  const logModal = document.getElementById("log-details-modal");
  const closeModalBtn = document.getElementById("close-modal-btn");
  const modalLogTitle = document.getElementById("modal-log-title");
  const modalLogBody = document.getElementById("modal-log-body");

  let allLogsCache = [];
  let registeredAgentsCache = [];

  // --- TAB NAVIGATION ---
  const tabTitles = {
    "chat-view": { title: "Chat Workspace", desc: "Intelligent multi-agent routing & task orchestration" },
    "dashboard-view": { title: "Enterprise Analytics Dashboard", desc: "Live SQLite workload metrics & execution KPIs" },
    "logs-view": { title: "Execution Audit Logs", desc: "Immutable transaction logs persisted in SQLite database" },
    "agents-view": { title: "Specialized Agent Registry", desc: "Domain agent profiles, capabilities, and operational readiness" }
  };

  navItems.forEach(item => {
    item.addEventListener("click", () => {
      const targetTab = item.getAttribute("data-tab");
      
      navItems.forEach(n => n.classList.remove("active"));
      viewPanels.forEach(p => p.classList.remove("active"));

      item.classList.add("active");
      const activePanel = document.getElementById(targetTab);
      if (activePanel) activePanel.classList.add("active");

      if (tabTitles[targetTab]) {
        currentViewTitle.textContent = tabTitles[targetTab].title;
        currentViewDesc.textContent = tabTitles[targetTab].desc;
      }

      // Lazy load tab data
      if (targetTab === "dashboard-view") loadDashboardStats();
      if (targetTab === "logs-view") loadExecutionLogs();
      if (targetTab === "agents-view") loadAgentsRegistry();
    });
  });

  // --- AUTO RESIZE TEXTAREA ---
  userInput.addEventListener("input", function() {
    this.style.height = "auto";
    this.style.height = (this.scrollHeight) + "px";
  });

  userInput.addEventListener("keydown", function(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      chatForm.dispatchEvent(new Event("submit"));
    }
  });

  clearInputBtn.addEventListener("click", () => {
    userInput.value = "";
    userInput.style.height = "auto";
    userInput.focus();
  });

  // --- TEST PROMPT CHIPS ---
  promptChips.forEach(chip => {
    chip.addEventListener("click", () => {
      const promptText = chip.getAttribute("data-prompt");
      userInput.value = promptText;
      userInput.style.height = "auto";
      chatForm.dispatchEvent(new Event("submit"));
    });
  });

  // --- REFRESH BUTTONS ---
  refreshDataBtn.addEventListener("click", () => {
    loadDashboardStats();
    loadExecutionLogs();
  });

  if (refreshLogsBtn) {
    refreshLogsBtn.addEventListener("click", loadExecutionLogs);
  }

  // --- LOG MODAL HANDLERS ---
  closeModalBtn.addEventListener("click", () => {
    logModal.classList.remove("open");
  });

  window.addEventListener("click", (e) => {
    if (e.target === logModal) {
      logModal.classList.remove("open");
    }
  });

  // --- CHAT FORM SUBMIT ---
  chatForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const query = userInput.value.trim();
    if (!query) return;

    // 1. Render User Message
    renderUserMessage(query);
    userInput.value = "";
    userInput.style.height = "auto";
    userInput.focus();

    // 2. Render Loading/Typing Indicator
    const typingIndicator = renderTypingIndicator();
    scrollChatToBottom();

    // Disable send button while processing
    sendBtn.disabled = true;

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: query })
      });

      const data = await response.json();
      typingIndicator.remove();

      if (data.success) {
        renderBotMessage(data);
      } else {
        renderErrorMessage(data.error || "Execution failed.");
      }

      // Update background statistics
      loadDashboardStats();
    } catch (err) {
      typingIndicator.remove();
      renderErrorMessage(`Network or server connection failed: ${err.message}`);
    } finally {
      sendBtn.disabled = false;
      scrollChatToBottom();
    }
  });

  // --- RENDER FUNCTIONS ---
  function renderUserMessage(text) {
    const msgEl = document.createElement("div");
    msgEl.className = "chat-message user-message";
    msgEl.innerHTML = `
      <div class="message-avatar user-avatar">
        <i class="fa-solid fa-user"></i>
      </div>
      <div class="message-content">
        <div class="message-header">
          <span class="agent-name">Enterprise User</span>
        </div>
        <div class="message-body">
          <p>${escapeHtml(text)}</p>
        </div>
      </div>
    `;
    chatStream.appendChild(msgEl);
    scrollChatToBottom();
  }

  function renderTypingIndicator() {
    const indEl = document.createElement("div");
    indEl.className = "chat-message bot-message";
    indEl.id = "active-typing-indicator";
    indEl.innerHTML = `
      <div class="message-avatar coordinator-avatar">
        <i class="fa-solid fa-sitemap"></i>
      </div>
      <div class="message-content">
        <div class="typing-indicator-box">
          <div class="typing-dots">
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
          </div>
          <span class="typing-text">Coordinator Agent: classifying intent & dispatching...</span>
        </div>
      </div>
    `;
    chatStream.appendChild(indEl);
    return indEl;
  }

  function renderBotMessage(data) {
    const msgEl = document.createElement("div");
    msgEl.className = "chat-message bot-message";

    const agentClass = getAgentStyleKey(data.selected_agent);
    const agentIcon = getAgentIcon(data.selected_agent);
    const isFunctional = (data.agent_type || "").toLowerCase().includes("functional");
    const roleBadgeClass = isFunctional ? "functional" : "prototype";
    const statusText = isFunctional ? "Functional Agent" : "Modular Prototype";

    // Build Execution Stepper HTML
    let stepperHtml = "";
    if (data.execution_steps && data.execution_steps.length > 0) {
      const stepItemsHtml = data.execution_steps.map(s => `
        <div class="step-item">
          <i class="fa-solid fa-circle-check step-icon"></i>
          <div>
            <div class="step-title">${escapeHtml(s.step)}</div>
            <div class="step-detail">${escapeHtml(s.detail)}</div>
          </div>
          <div class="step-time">${s.duration_ms}ms</div>
        </div>
      `).join("");

      stepperHtml = `
        <div class="execution-stepper">
          <div class="stepper-header" onclick="this.nextElementSibling.classList.toggle('open')">
            <span><i class="fa-solid fa-diagram-project"></i> Pipeline Execution Steps (${data.execution_steps.length} steps)</span>
            <span><i class="fa-solid fa-chevron-down"></i></span>
          </div>
          <div class="stepper-content">
            ${stepItemsHtml}
          </div>
        </div>
      `;
    }

    // Convert markdown in response
    const formattedHtml = parseMarkdown(data.response || "");

    msgEl.innerHTML = `
      <div class="message-avatar agent-avatar ${agentClass}">
        <i class="${agentIcon}"></i>
      </div>
      <div class="message-content">
        <div class="message-header">
          <span class="agent-name">${escapeHtml(data.selected_agent)}</span>
          <span class="role-badge ${roleBadgeClass}">${statusText}</span>
          <span class="latency-badge"><i class="fa-solid fa-gauge-high"></i> ${data.total_time_ms}ms</span>
          <span class="latency-badge"><i class="fa-solid fa-bullseye"></i> Intent: ${escapeHtml(data.detected_intent)} (${Math.round(data.confidence * 100)}%)</span>
        </div>
        ${stepperHtml}
        <div class="message-body">
          ${formattedHtml}
        </div>
      </div>
    `;

    chatStream.appendChild(msgEl);
    scrollChatToBottom();
  }

  function renderErrorMessage(errorText) {
    const msgEl = document.createElement("div");
    msgEl.className = "chat-message bot-message";
    msgEl.innerHTML = `
      <div class="message-avatar agent-avatar" style="background: #ef4444;">
        <i class="fa-solid fa-triangle-exclamation"></i>
      </div>
      <div class="message-content">
        <div class="message-header">
          <span class="agent-name" style="color: #ef4444;">System Orchestrator</span>
          <span class="role-badge" style="background:#fee2e2; color:#991b1b;">Error</span>
        </div>
        <div class="message-body" style="border-left: 3px solid #ef4444;">
          <p><strong>Workflow Exception:</strong> ${escapeHtml(errorText)}</p>
        </div>
      </div>
    `;
    chatStream.appendChild(msgEl);
    scrollChatToBottom();
  }

  function scrollChatToBottom() {
    chatStream.scrollTop = chatStream.scrollHeight;
  }

  // --- DASHBOARD DATA FETCHER ---
  async function loadDashboardStats() {
    try {
      const res = await fetch("/api/stats");
      const result = await res.json();
      if (!result.success) return;

      const stats = result.stats;

      // Metric Cards
      statTotalRequests.textContent = stats.total_requests;
      statSuccessRate.textContent = `${stats.success_rate}%`;
      statSuccessfulCount.textContent = `${stats.successful_requests} of ${stats.total_requests} successful`;
      statAvgLatency.textContent = `${stats.avg_latency_ms} ms`;

      // Agent Workload Distribution Bars
      const distribution = stats.agent_distribution || {};
      const agentKeys = Object.keys(distribution);

      if (agentKeys.length === 0) {
        agentDistributionContainer.innerHTML = `<div class="empty-state">No requests executed yet. Run one of the test prompts above!</div>`;
      } else {
        const total = stats.total_requests || 1;
        agentDistributionContainer.innerHTML = agentKeys.map(agent => {
          const count = distribution[agent];
          const pct = Math.round((count / total) * 100);
          return `
            <div class="distribution-item">
              <div class="dist-meta">
                <span>${escapeHtml(agent)}</span>
                <span><strong>${count}</strong> (${pct}%)</span>
              </div>
              <div class="dist-bar-track">
                <div class="dist-bar-fill" style="width: ${pct}%;"></div>
              </div>
            </div>
          `;
        }).join("");
      }

      // Recent Activity Stream
      const activity = stats.recent_activity || [];
      if (activity.length === 0) {
        recentActivityContainer.innerHTML = `<div class="empty-state">No recent activity.</div>`;
      } else {
        recentActivityContainer.innerHTML = activity.map(item => {
          const isSuccess = item.task_status === "SUCCESS";
          return `
            <div class="activity-item ${isSuccess ? 'success' : 'failed'}">
              <div class="activity-text" title="${escapeHtml(item.user_request)}">
                ${escapeHtml(item.user_request)}
              </div>
              <div class="activity-meta">
                <span><strong>${escapeHtml(item.selected_agent)}</strong></span>
                <span>${item.execution_time_ms}ms</span>
                <span class="status-badge ${isSuccess ? 'success' : 'failed'}">${item.task_status}</span>
              </div>
            </div>
          `;
        }).join("");
      }

      // Agent Status Table
      loadAgentStatusTable();

    } catch (e) {
      console.error("Failed to load dashboard stats", e);
    }
  }

  // --- AGENT STATUS TABLE ---
  async function loadAgentStatusTable() {
    if (!registeredAgentsCache || registeredAgentsCache.length === 0) {
      try {
        const res = await fetch("/api/agents");
        const json = await res.json();
        if (json.success) registeredAgentsCache = json.agents;
      } catch (e) {
        console.error("Failed to fetch agents", e);
      }
    }

    if (!registeredAgentsCache) return;

    agentStatusTableBody.innerHTML = registeredAgentsCache.map(agent => {
      const isFunc = agent.status.toLowerCase().includes("functional");
      const badgeClass = isFunc ? "success" : "prototype";
      return `
        <tr>
          <td><strong>${escapeHtml(agent.name)}</strong></td>
          <td><code>${escapeHtml(agent.module)}</code></td>
          <td><span class="status-badge ${badgeClass}">${escapeHtml(agent.status)}</span></td>
          <td>${agent.capabilities.map(c => `<span class="capability-pill">${escapeHtml(c)}</span>`).join(" ")}</td>
          <td><span class="status-badge ${isFunc ? 'success' : 'failed'}">${isFunc ? 'Active SQLite' : 'Rule/Template'}</span></td>
        </tr>
      `;
    }).join("");
  }

  // --- AUDIT LOGS FETCHER ---
  async function loadExecutionLogs() {
    try {
      auditLogsTbody.innerHTML = `<tr><td colspan="8" class="text-center">Fetching SQLite audit logs...</td></tr>`;
      const res = await fetch("/api/logs?limit=50");
      const json = await res.json();
      if (!json.success) return;

      allLogsCache = json.logs || [];
      renderAuditLogsTable(allLogsCache);
    } catch (e) {
      auditLogsTbody.innerHTML = `<tr><td colspan="8" class="text-center text-danger">Error loading audit logs: ${e.message}</td></tr>`;
    }
  }

  function renderAuditLogsTable(logs) {
    if (!logs || logs.length === 0) {
      auditLogsTbody.innerHTML = `<tr><td colspan="8" class="empty-state">No execution logs found in SQLite. Run a chat query to record executions.</td></tr>`;
      return;
    }

    auditLogsTbody.innerHTML = logs.map(l => {
      const isSuccess = l.task_status === "SUCCESS";
      return `
        <tr class="clickable-row" data-log-id="${l.id}">
          <td><strong>#${l.id}</strong></td>
          <td><small>${escapeHtml(l.timestamp)}</small></td>
          <td title="${escapeHtml(l.user_request)}"><strong>${escapeHtml(truncate(l.user_request, 45))}</strong></td>
          <td><span class="capability-pill">${escapeHtml(l.detected_intent)}</span></td>
          <td>${escapeHtml(l.selected_agent)}</td>
          <td>${Math.round(l.confidence * 100)}%</td>
          <td>${l.execution_time_ms} ms</td>
          <td><span class="status-badge ${isSuccess ? 'success' : 'failed'}">${l.task_status}</span></td>
        </tr>
      `;
    }).join("");

    // Add click listeners to rows for modal view
    document.querySelectorAll(".clickable-row").forEach(row => {
      row.addEventListener("click", () => {
        const logId = parseInt(row.getAttribute("data-log-id"));
        const record = allLogsCache.find(r => r.id === logId);
        if (record) showLogDetailsModal(record);
      });
    });
  }

  // Log Search Filtering
  if (logSearchInput) {
    logSearchInput.addEventListener("input", (e) => {
      const q = e.target.value.toLowerCase().trim();
      if (!q) {
        renderAuditLogsTable(allLogsCache);
        return;
      }
      const filtered = allLogsCache.filter(l => 
        l.user_request.toLowerCase().includes(q) ||
        l.selected_agent.toLowerCase().includes(q) ||
        l.detected_intent.toLowerCase().includes(q)
      );
      renderAuditLogsTable(filtered);
    });
  }

  function showLogDetailsModal(record) {
    modalLogTitle.textContent = `Audit Log #${record.id} — ${record.selected_agent}`;
    
    let stepsHtml = "";
    if (record.details && record.details.steps) {
      stepsHtml = `
        <div style="margin-top: 14px;">
          <strong>Pipeline Steps Recorded:</strong>
          <ul style="margin-top: 6px; padding-left: 18px;">
            ${record.details.steps.map(s => `<li><strong>${escapeHtml(s.step)}</strong> (${s.duration_ms}ms) &mdash; <span style="color:#64748b;">${escapeHtml(s.detail)}</span></li>`).join("")}
          </ul>
        </div>
      `;
    }

    modalLogBody.innerHTML = `
      <div style="display: flex; flex-direction: column; gap: 10px;">
        <div><strong>Timestamp:</strong> ${escapeHtml(record.timestamp)}</div>
        <div><strong>User Prompt:</strong> <span style="color:#4f46e5;">${escapeHtml(record.user_request)}</span></div>
        <div><strong>Detected Intent:</strong> <code>${escapeHtml(record.detected_intent)}</code> (Confidence: ${Math.round(record.confidence * 100)}%)</div>
        <div><strong>Executing Agent:</strong> ${escapeHtml(record.selected_agent)}</div>
        <div><strong>Execution Latency:</strong> ${record.execution_time_ms} ms</div>
        <div><strong>Status:</strong> <span class="status-badge ${record.task_status === 'SUCCESS' ? 'success' : 'failed'}">${record.task_status}</span></div>
        ${stepsHtml}
        <div style="margin-top: 12px;">
          <strong>Formatted Agent Output:</strong>
          <div style="background:#f8fafc; border:1px solid #e2e8f0; padding:12px; border-radius:8px; margin-top:6px; max-height:220px; overflow-y:auto;">
            ${parseMarkdown(record.agent_response)}
          </div>
        </div>
      </div>
    `;

    logModal.classList.add("open");
  }

  // --- AGENTS REGISTRY FETCHER ---
  async function loadAgentsRegistry() {
    try {
      const res = await fetch("/api/agents");
      const json = await res.json();
      if (!json.success) return;

      registeredAgentsCache = json.agents;
      agentsCardsGrid.innerHTML = registeredAgentsCache.map(agent => {
        const isFunc = agent.status.toLowerCase().includes("functional");
        const agentKey = getAgentStyleKey(agent.name);
        const icon = getAgentIcon(agent.name);
        
        return `
          <div class="agent-dir-card">
            <div class="agent-dir-header">
              <div class="agent-dir-icon ${agentKey}">
                <i class="${icon}"></i>
              </div>
              <div class="agent-dir-info">
                <h4>${escapeHtml(agent.name)}</h4>
                <div class="module-path">${escapeHtml(agent.module)}</div>
              </div>
            </div>
            
            <div style="display:flex; gap:6px;">
              <span class="status-badge ${isFunc ? 'success' : 'prototype'}">${escapeHtml(agent.badge)}</span>
            </div>

            <p class="agent-dir-desc">${escapeHtml(agent.description)}</p>

            <div class="agent-capabilities-list">
              ${agent.capabilities.map(c => `<span class="capability-pill"><i class="fa-solid fa-check"></i> ${escapeHtml(c)}</span>`).join("")}
            </div>

            <div class="agent-sample-box">
              <span class="agent-sample-label">Sample Enterprise Prompt</span>
              <span class="agent-sample-query" data-sample="${escapeHtml(agent.example_query)}">
                <i class="fa-regular fa-paper-plane"></i> "${escapeHtml(agent.example_query)}"
              </span>
            </div>
          </div>
        `;
      }).join("");

      // Attach clicks to sample queries
      document.querySelectorAll(".agent-sample-query").forEach(btn => {
        btn.addEventListener("click", () => {
          const prompt = btn.getAttribute("data-sample");
          // Switch to chat view
          document.querySelector("[data-tab='chat-view']").click();
          userInput.value = prompt;
          userInput.style.height = "auto";
          chatForm.dispatchEvent(new Event("submit"));
        });
      });

    } catch (e) {
      console.error("Failed to load agents directory", e);
    }
  }

  // --- HELPER FUNCTIONS ---
  function getAgentStyleKey(name) {
    if (!name) return "hr";
    const n = name.toLowerCase();
    if (n.includes("hr")) return "hr";
    if (n.includes("finance")) return "finance";
    if (n.includes("coding")) return "coding";
    if (n.includes("email")) return "email";
    if (n.includes("data")) return "data";
    if (n.includes("support")) return "support";
    return "hr";
  }

  function getAgentIcon(name) {
    if (!name) return "fa-solid fa-robot";
    const n = name.toLowerCase();
    if (n.includes("hr")) return "fa-solid fa-user-check";
    if (n.includes("finance")) return "fa-solid fa-calculator";
    if (n.includes("coding")) return "fa-solid fa-code";
    if (n.includes("email")) return "fa-solid fa-envelope";
    if (n.includes("data")) return "fa-solid fa-chart-line";
    if (n.includes("support")) return "fa-solid fa-headset";
    return "fa-solid fa-robot";
  }

  function escapeHtml(str) {
    if (!str) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function truncate(str, len) {
    if (!str) return "";
    return str.length > len ? str.substring(0, len) + "..." : str;
  }

  // Lightweight Markdown to HTML Parser for Assistant Responses
  function parseMarkdown(md) {
    if (!md) return "";

    let html = md;

    // Code blocks ```lang ... ```
    html = html.replace(/```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g, (match, lang, code) => {
      return `<pre><code>${escapeHtml(code.trim())}</code></pre>`;
    });

    // Inline code `code`
    html = html.replace(/`([^`]+)`/g, (match, code) => {
      return `<code>${escapeHtml(code)}</code>`;
    });

    // Markdown Tables
    html = html.replace(/((?:\|[^\n]+\|\r?\n)+)/g, (match) => {
      const lines = match.trim().split(/\r?\n/).filter(l => l.trim().startsWith("|"));
      if (lines.length < 2) return match;

      let tableHtml = "<table>";
      let isHeader = true;

      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (line.includes("---")) {
          isHeader = false;
          continue; // Separator row
        }

        const cells = line.split("|").slice(1, -1).map(c => c.trim());
        const tag = isHeader ? "th" : "td";

        tableHtml += "<tr>";
        for (const cell of cells) {
          tableHtml += `<${tag}>${formatInlineText(cell)}</${tag}>`;
        }
        tableHtml += "</tr>";

        if (isHeader && i === 0 && lines[1] && lines[1].includes("---")) {
          // next will be separator
        }
      }
      tableHtml += "</table>";
      return tableHtml;
    });

    // Headers
    html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
    html = html.replace(/^#### (.*$)/gim, '<h4>$1</h4>');

    // Blockquotes
    html = html.replace(/^> (.*$)/gim, '<blockquote>$1</blockquote>');

    // Bold & Italic
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\*([^*]+)\*/g, '<em>$1</em>');

    // Bullet lists
    html = html.replace(/^- (.*$)/gim, '<li>$1</li>');
    html = html.replace(/((?:<li>.*<\/li>\s*)+)/gim, '<ul>$1</ul>');

    // Paragraphs
    html = html.split('\n\n').map(p => {
      p = p.trim();
      if (!p) return "";
      if (p.startsWith('<h') || p.startsWith('<pre') || p.startsWith('<table') || p.startsWith('<ul') || p.startsWith('<block')) {
        return p;
      }
      return `<p>${p}</p>`;
    }).join('');

    return html;
  }

  function formatInlineText(text) {
    let t = text;
    t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    t = t.replace(/\*([^*]+)\*/g, '<em>$1</em>');
    t = t.replace(/`([^`]+)`/g, '<code>$1</code>');
    return t;
  }

  // Initial Load
  loadDashboardStats();
  loadAgentsRegistry();
});
