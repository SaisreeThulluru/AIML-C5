"""
tests/test_ground_truth.py
Pytest suite verifying GroundTruthVerifier deterministic assertions and pass/fail reporting.
"""

import pytest
from evaluation.ground_truth import GroundTruthVerifier


@pytest.fixture
def verifier(db_session):
    v = GroundTruthVerifier(db=db_session)
    return v


def test_verify_employee_existence_pass(verifier):
    """Assert existing employee EMP-001 yields PASS."""
    res = verifier.verify_employee_existence("EMP-001")
    assert res.status == "PASS"
    assert res.expected is True
    assert res.actual is True
    assert "EMP-001" in res.explanation


def test_verify_employee_existence_fail(verifier):
    """Assert non-existent employee EMP-999 yields FAIL."""
    res = verifier.verify_employee_existence("EMP-999")
    assert res.status == "FAIL"
    assert res.actual is False


def test_verify_employee_details_pass(verifier):
    """Assert matching employee details yields PASS."""
    expected = {
        "full_name": "Alice Chen",
        "department": "Engineering",
        "status": "Active"
    }
    res = verifier.verify_employee_details("EMP-001", expected)
    assert res.status == "PASS"
    assert res.actual["full_name"] == "Alice Chen"


def test_verify_employee_details_fail(verifier):
    """Assert mismatching employee details yields FAIL with clear explanation."""
    expected = {
        "full_name": "Alice Chen",
        "department": "Finance"  # Incorrect department
    }
    res = verifier.verify_employee_details("EMP-001", expected)
    assert res.status == "FAIL"
    assert "department" in res.explanation


def test_verify_leave_balance_pass(verifier):
    """Assert correct leave balance computation yields PASS."""
    res = verifier.verify_leave_balance("EMP-002", 18)
    assert res.status == "PASS"
    assert res.expected == 18
    assert res.actual == 18


def test_verify_leave_balance_fail(verifier):
    """Assert incorrect leave balance expectation yields FAIL."""
    res = verifier.verify_leave_balance("EMP-002", 22)
    assert res.status == "FAIL"
    assert res.expected == 22
    assert res.actual == 18


def test_verify_task_outcome_pass(verifier):
    """Assert valid candidate output for TASK-HR-001 yields PASS."""
    candidate_output = {
        "employee_id": "EMP-001",
        "full_name": "Alice Chen",
        "department": "Engineering",
        "role": "Senior Software Engineer",
        "status": "Active"
    }
    res = verifier.verify_task_outcome("TASK-HR-001", candidate_output)
    assert res.status == "PASS"
