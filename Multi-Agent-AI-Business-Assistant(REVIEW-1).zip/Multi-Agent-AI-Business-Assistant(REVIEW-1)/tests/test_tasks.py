"""
tests/test_tasks.py
Pytest suite verifying benchmark enterprise task dataset specifications.
"""

import json
import os
import pytest

DATASET_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "datasets",
    "sample_tasks.json"
)


@pytest.fixture
def tasks_data():
    assert os.path.exists(DATASET_PATH), f"Dataset missing at {DATASET_PATH}"
    with open(DATASET_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def test_task_count(tasks_data):
    """Assert exactly 15 benchmark enterprise tasks exist for Week 1."""
    assert len(tasks_data) == 15


def test_all_six_departments_covered(tasks_data):
    """Assert coverage of all 6 required enterprise departments."""
    required_depts = {
        "Human Resources",
        "Finance",
        "Software Engineering",
        "Email Communication",
        "Data Analytics",
        "Customer Support",
    }
    actual_depts = {t["department"] for t in tasks_data}
    assert required_depts.issubset(actual_depts), f"Missing departments: {required_depts - actual_depts}"


def test_mandatory_task_fields(tasks_data):
    """Assert every task contains all 8 mandatory schema attributes."""
    mandatory_fields = [
        "task_id",
        "department",
        "task_description",
        "input_parameters",
        "expected_output",
        "expected_outcome",
        "verification_criteria",
        "difficulty_level",
    ]
    task_ids = set()
    for task in tasks_data:
        for field in mandatory_fields:
            assert field in task, f"Task {task.get('task_id')} missing required field: {field}"
        # Unique task ID check
        assert task["task_id"] not in task_ids, f"Duplicate task_id found: {task['task_id']}"
        task_ids.add(task["task_id"])


def test_difficulty_levels(tasks_data):
    """Assert valid difficulty classifications."""
    allowed_difficulties = {"Easy", "Medium", "Hard"}
    for task in tasks_data:
        assert task["difficulty_level"] in allowed_difficulties, (
            f"Invalid difficulty '{task['difficulty_level']}' in {task['task_id']}"
        )
