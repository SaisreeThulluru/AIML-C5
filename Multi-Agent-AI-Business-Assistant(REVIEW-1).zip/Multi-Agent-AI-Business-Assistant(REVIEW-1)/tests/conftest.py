"""
tests/conftest.py
Shared Pytest Fixtures for Enterprise Test Suite.
"""

import pytest
from backend.database import SessionLocal, init_db


@pytest.fixture(scope="session", autouse=True)
def initialize_test_database():
    """Seeds the SQLite database once for the entire test session."""
    init_db()


@pytest.fixture
def db_session():
    """Provides a transactional database session fixture for individual test cases."""
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()
