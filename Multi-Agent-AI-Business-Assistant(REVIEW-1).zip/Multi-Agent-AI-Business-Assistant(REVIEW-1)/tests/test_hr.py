"""
tests/test_hr.py
Pytest suite for Mock HR System service functions and queries.
"""

from backend.services.hr_service import (
    get_all_employees,
    get_employee_by_id,
    search_employees,
    get_employee_leave_balance,
)


def test_get_all_employees(db_session):
    """Assert retrieval of all active employees."""
    employees = get_all_employees(db_session)
    assert len(employees) >= 5
    emp_ids = [e.employee_id for e in employees]
    assert "EMP-001" in emp_ids
    assert "EMP-002" in emp_ids


def test_get_all_employees_with_department_filter(db_session):
    """Assert department filtering isolates correct employees."""
    eng_employees = get_all_employees(db_session, department="Engineering")
    assert len(eng_employees) >= 1
    assert all(e.department == "Engineering" for e in eng_employees)


def test_get_employee_by_id(db_session):
    """Assert exact retrieval of employee profile."""
    emp = get_employee_by_id(db_session, "EMP-001")
    assert emp is not None
    assert emp.full_name == "Alice Chen"
    assert emp.department == "Engineering"
    assert emp.role == "Senior Software Engineer"
    assert emp.status == "Active"


def test_get_employee_by_invalid_id(db_session):
    """Assert non-existent employee ID returns None."""
    emp = get_employee_by_id(db_session, "EMP-999")
    assert emp is None


def test_search_employees(db_session):
    """Assert search finds matches across name and role."""
    results = search_employees(db_session, "Alice")
    assert len(results) >= 1
    assert results[0].employee_id == "EMP-001"

    role_results = search_employees(db_session, "Financial")
    assert len(role_results) >= 1
    assert role_results[0].employee_id == "EMP-002"


def test_leave_balance_calculation(db_session):
    """Assert leave balance calculation: total (24) - taken (6) = 18 remaining."""
    balance = get_employee_leave_balance(db_session, "EMP-002")
    assert balance is not None
    assert balance["employee_id"] == "EMP-002"
    assert balance["full_name"] == "Bob Smith"
    assert balance["total_allocated"] == 24
    assert balance["approved_leaves_taken"] == 6
    assert balance["remaining_leaves"] == 18


def test_leave_balance_invalid_employee(db_session):
    """Assert calculating leave for non-existent employee returns None."""
    balance = get_employee_leave_balance(db_session, "EMP-999")
    assert balance is None
