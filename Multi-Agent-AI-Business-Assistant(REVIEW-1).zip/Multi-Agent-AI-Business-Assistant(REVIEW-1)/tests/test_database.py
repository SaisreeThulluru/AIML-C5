"""
tests/test_database.py
Pytest suite verifying SQLite schema integrity, tables, and seeded enterprise data.
"""

from sqlalchemy import inspect
from backend.database import engine
from backend.models import (
    Department,
    Employee,
    LeaveRecord,
    Payroll,
    Reimbursement,
    EmailDraft,
    SupportTicket,
)


def test_tables_exist():
    """Assert all 7 required enterprise tables exist in SQLite."""
    inspector = inspect(engine)
    table_names = inspector.get_table_names()

    required_tables = [
        "departments",
        "employees",
        "leave_records",
        "payroll",
        "reimbursements",
        "email_drafts",
        "support_tickets",
    ]
    for table in required_tables:
        assert table in table_names, f"Expected table '{table}' not found in database."


def test_seeded_record_counts(db_session):
    """Assert minimum fictional records exist across all enterprise tables."""
    assert db_session.query(Department).count() >= 6, "Expected at least 6 departments."
    assert db_session.query(Employee).count() >= 5, "Expected at least 5 employees."
    assert db_session.query(LeaveRecord).count() >= 3, "Expected at least 3 leave records."
    assert db_session.query(Payroll).count() >= 2, "Expected at least 2 payroll records."
    assert db_session.query(Reimbursement).count() >= 2, "Expected at least 2 reimbursement records."
    assert db_session.query(EmailDraft).count() >= 2, "Expected at least 2 email drafts."
    assert db_session.query(SupportTicket).count() >= 2, "Expected at least 2 support tickets."


def test_employee_relationships(db_session):
    """Assert relational ORM joins between Employees and LeaveRecords work correctly."""
    emp2 = db_session.query(Employee).filter(Employee.employee_id == "EMP-002").first()
    assert emp2 is not None
    assert len(emp2.leave_records) >= 2
    assert emp2.dept_relation.name == "Finance"
