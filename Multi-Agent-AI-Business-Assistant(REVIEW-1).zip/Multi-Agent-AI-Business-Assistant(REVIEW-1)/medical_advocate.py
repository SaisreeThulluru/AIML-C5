import streamlit as st
from google import genai
from google.genai import types
from PIL import Image
import json
import os

# Initialize the Gemini client 
# Note: You must have your GEMINI_API_KEY set as an environment variable
try:
    client = genai.Client()
except Exception as e:
    st.error("Failed to initialize Gemini Client. Make sure your GEMINI_API_KEY environment variable is set.")

# --- MOCK DATABASE (Phase 2 Simulation) ---
# In a full production app, this would query a real ICD-10/CPT database via API.
MEDICAL_CODES = {
    "99214": "Office or other outpatient visit for the evaluation and management of an established patient (Moderate complexity)",
    "J0171": "Injection, Adrenalin, epinephrine, 0.1 mg",
    "E0424": "Stationary compressed gaseous oxygen system",
    "J45.909": "Unspecified asthma, uncomplicated",
    "I10": "Essential (primary) hypertension"
}

# --- UI CONFIGURATION ---
st.set_page_config(page_title="Medical Advocate Agent", layout="wide")

st.title("⚕️ Autonomous Medical Insurance Advocate")
st.markdown("### Prototype MVP")
st.warning("⚠️ **PROTOTYPE ONLY:** Do not upload actual Protected Health Information (PHI) or real medical bills to this instance.")

# --- STEP 1: UPLOAD & INGESTION ---
st.markdown("#### Step 1: Upload Denial Letter or Bill")
uploaded_file = st.file_uploader("Upload Image (PNG/JPG)", type=['png', 'jpg', 'jpeg'])

if uploaded_file is not None:
    col1, col2 = st.columns(2)
    
    with col1:
        image = Image.open(uploaded_file)
        st.image(image, caption="Uploaded Document", use_container_width=True)

    with col2:
        if st.button("Extract Data & Codes (Run Vision Agent)"):
            with st.spinner("Extracting data via Vision AI..."):
                prompt = """
                Analyze this medical bill or insurance denial letter. Extract the following information and return ONLY a valid JSON object.
                {
                    "patient_name": "string or null",
                    "date_of_service": "string or null",
                    "provider_name": "string or null",
                    "denial_reason": "string or null",
                    "cpt_codes": ["list of strings"],
                    "icd10_codes": ["list of strings"]
                }
                If a field is not found, use null. Look closely for codes (e.g., 99214, J45.9).
                """
                
                try:
                    # Using Gemini Flash for fast vision extraction
                    response = client.models.generate_content(
                        model='gemini-2.5-flash',
                        contents=[image, prompt],
                        config=types.GenerateContentConfig(response_mime_type="application/json")
                    )
                    
                    extracted_data = json.loads(response.text)
                    st.session_state['extracted_data'] = extracted_data
                    st.success("Extraction Complete!")
                    st.json(extracted_data)
                except Exception as e:
                    st.error(f"Failed to extract data: {e}")

# --- STEP 2: REASONING & DRAFTING ---
if 'extracted_data' in st.session_state:
    st.markdown("---")
    st.markdown("#### Step 2: Agentic Reasoning & Drafting")
    if st.button("Cross-Reference Codes & Draft Appeal"):
        with st.spinner("Looking up medical codes and drafting legal appeal..."):
            data = st.session_state['extracted_data']
            
            # --- RAG / Tool Use Simulation ---
            # The agent looks up the codes extracted from the image in its database
            code_definitions = []
            for code in data.get('cpt_codes', []) + data.get('icd10_codes', []):
                if code in MEDICAL_CODES:
                    code_definitions.append(f"- **{code}**: {MEDICAL_CODES[code]}")
                else:
                    code_definitions.append(f"- **{code}**: [Definition requires external database lookup]")
            
            enrichment_text = "\n".join(code_definitions)
            
            # Show the user what the agent found
            st.info(f"**Agent Code Lookup Results:**\n{enrichment_text}")
            
            # --- DRAFTING ---
            draft_prompt = f"""
            You are an expert medical billing advocate. Write a formal, professional, and persuasive appeal letter to an insurance company.
            
            Patient Data:
            {json.dumps(data, indent=2)}
            
            Medical Code Definitions (Ground Truth):
            {enrichment_text}
            
            Instructions:
            1. Address it "To the Appeals Department".
            2. State clearly that we are appealing the denial for the specified dates of service.
            3. Use the medical code definitions to argue logically why the service/procedure was medically necessary for the given diagnosis.
            4. Tone must be assertive, highly professional, and legally sound. Do not be overly aggressive, but be firm.
            5. Leave placeholders like [Your Name] for the patient to sign.
            """
            
            try:
                # Using Gemini Pro for advanced reasoning and writing
                draft_response = client.models.generate_content(
                    model='gemini-2.5-pro',
                    contents=draft_prompt
                )
                
                st.subheader("Drafted Appeal Letter")
                st.text_area("Review and Edit (Ready to Send):", value=draft_response.text, height=500)
                
                st.success("Phase 3 Integration: In a full deployment, clicking 'Approve' here would trigger an API (like Phaxio or SendGrid) to automatically fax/email this to the provider.")
                
            except Exception as e:
                st.error(f"Failed to draft letter: {e}")
