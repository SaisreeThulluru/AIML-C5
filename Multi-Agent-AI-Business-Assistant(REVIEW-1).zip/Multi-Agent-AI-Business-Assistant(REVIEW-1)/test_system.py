"""
test_system.py
End-to-End Automated Test Suite for Multi-Agent AI Business Assistant.
Tests all 6 required prompts, Coordinator orchestration, SQLite logging, and REST APIs.
"""

import sys
import os
import json

# Ensure UTF-8 output on Windows terminal
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from backend.intent_router import IntentRouter
from backend.coordinator import CoordinatorAgent
from backend.database import init_db, get_dashboard_stats, get_recent_logs, get_db_connection
from backend.app import app


def run_tests():
    print("=" * 70)
    print("[*] STARTING MULTI-AGENT SYSTEM AUTOMATED TESTS")
    print("=" * 70)

    # 1. Initialize SQLite Database
    print("\n[Test 1] Initializing SQLite Database...")
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [r[0] for r in cursor.fetchall()]
    conn.close()
    print(f"  -> Found Tables: {tables}")
    assert "execution_logs" in tables, "execution_logs table missing"
    assert "employees" in tables, "employees table missing"
    assert "payroll_records" in tables, "payroll_records table missing"
    assert "sales_data" in tables, "sales_data table missing"
    assert "support_tickets" in tables, "support_tickets table missing"
    print("  [OK] Database initialization and schema verification: PASSED")

    # 2. Test the 6 Mandatory Prompts
    test_cases = [
        {
            "id": 1,
            "prompt": "I want to onboard a new employee named Alice.",
            "expected_intent": "hr",
            "expected_agent": "HR Agent"
        },
        {
            "id": 2,
            "prompt": "Calculate the monthly salary for an employee with a basic salary of 40000.",
            "expected_intent": "finance",
            "expected_agent": "Finance Agent"
        },
        {
            "id": 3,
            "prompt": "Help me debug this Python code.",
            "expected_intent": "coding",
            "expected_agent": "Coding Agent"
        },
        {
            "id": 4,
            "prompt": "Draft an email requesting project approval.",
            "expected_intent": "email",
            "expected_agent": "Email Agent"
        },
        {
            "id": 5,
            "prompt": "Analyze the sales data.",
            "expected_intent": "data_analysis",
            "expected_agent": "Data Analysis Agent"
        },
        {
            "id": 6,
            "prompt": "A customer wants help with a product issue.",
            "expected_intent": "customer_support",
            "expected_agent": "Customer Support Agent"
        }
    ]

    print("\n[Test 2] Testing Intent Classification Engine on 6 Required Queries...")
    router = IntentRouter()
    for tc in test_cases:
        res = router.route(tc["prompt"])
        print(f"  Test #{tc['id']}: \"{tc['prompt']}\"")
        print(f"    -> Detected Intent: {res['intent']} (Confidence: {res['confidence']})")
        print(f"    -> Selected Agent:  {res['selected_agent']}")
        assert res["intent"] == tc["expected_intent"], f"Intent mismatch for Test #{tc['id']}: expected {tc['expected_intent']}, got {res['intent']}"
        assert res["selected_agent"] == tc["expected_agent"], f"Agent mismatch for Test #{tc['id']}: expected {tc['expected_agent']}, got {res['selected_agent']}"
    print("  [OK] All 6 Intent Routing tests: PASSED (100% accuracy)")

    # 3. Test Coordinator Agent End-to-End Orchestration & Execution
    print("\n[Test 3] Testing Central Coordinator Agent Orchestration & Agent Execution...")
    coordinator = CoordinatorAgent()

    for tc in test_cases:
        print(f"\n  Orchestrating Test #{tc['id']}: '{tc['prompt']}'")
        res = coordinator.process_request(tc["prompt"])
        assert res["success"] is True, f"Execution failed for {tc['prompt']}"
        assert res["selected_agent"] == tc["expected_agent"], "Agent routing mismatch"
        assert len(res["execution_steps"]) >= 4, "Execution steps missing"
        assert res["log_id"] > 0, "Log ID not generated"
        print(f"    -> Executing Agent: {res['selected_agent']} ({res['agent_type']})")
        print(f"    -> Total Latency:   {res['total_time_ms']} ms")
        print(f"    -> Steps Captured:  {len(res['execution_steps'])}")
        print(f"    -> SQLite Log ID:   #{res['log_id']}")
    print("\n  [OK] Coordinator orchestration & agent execution: PASSED")

    # 4. Verify SQLite Logging and Metrics
    print("\n[Test 4] Verifying Real SQLite Statistics & Audit Logs...")
    stats = get_dashboard_stats()
    print(f"  -> Total Requests Logged:    {stats['total_requests']}")
    print(f"  -> Successful Executions:   {stats['successful_requests']}")
    print(f"  -> Success Rate:            {stats['success_rate']}%")
    print(f"  -> Average Latency:         {stats['avg_latency_ms']} ms")
    print(f"  -> Agent Distribution:      {stats['agent_distribution']}")
    assert stats["total_requests"] >= 6, "Expected at least 6 logged requests"
    assert stats["success_rate"] == 100.0, "Expected 100% success rate"

    logs = get_recent_logs(limit=10)
    print(f"  -> Recent Logs Retrieved:    {len(logs)}")
    assert len(logs) >= 6, "Expected at least 6 recent logs"
    print("  [OK] SQLite persistence & dashboard metrics verification: PASSED")

    # 5. Test Flask REST Endpoints via Test Client
    print("\n[Test 5] Testing Flask REST Endpoints...")
    with app.test_client() as client:
        # GET /
        resp = client.get("/")
        assert resp.status_code == 200, "Frontend index.html failed to serve"
        print("  -> GET / [Frontend Index]: 200 OK")

        # GET /api/health
        resp = client.get("/api/health")
        assert resp.status_code == 200
        assert resp.get_json()["status"] == "healthy"
        print("  -> GET /api/health: 200 OK")

        # GET /api/agents
        resp = client.get("/api/agents")
        assert resp.status_code == 200
        agents = resp.get_json()["agents"]
        assert len(agents) == 6, f"Expected 6 agents, got {len(agents)}"
        print(f"  -> GET /api/agents: 200 OK ({len(agents)} agents returned)")

        # GET /api/stats
        resp = client.get("/api/stats")
        assert resp.status_code == 200
        assert resp.get_json()["success"] is True
        print("  -> GET /api/stats: 200 OK")

        # GET /api/logs
        resp = client.get("/api/logs")
        assert resp.status_code == 200
        assert resp.get_json()["success"] is True
        print("  -> GET /api/logs: 200 OK")

        # POST /api/chat
        post_resp = client.post("/api/chat", json={"message": "I want to onboard a new employee named Alice."})
        assert post_resp.status_code == 200
        post_data = post_resp.get_json()
        assert post_data["success"] is True
        assert post_data["selected_agent"] == "HR Agent"
        print("  -> POST /api/chat [Live Orchestration]: 200 OK")

    print("\n  [OK] Flask REST API Endpoints: PASSED")

    print("\n" + "=" * 70)
    print("[SUCCESS] ALL TESTS PASSED! PROTOTYPE IS 100% OPERATIONAL.")
    print("=" * 70)


if __name__ == "__main__":
    run_tests()
