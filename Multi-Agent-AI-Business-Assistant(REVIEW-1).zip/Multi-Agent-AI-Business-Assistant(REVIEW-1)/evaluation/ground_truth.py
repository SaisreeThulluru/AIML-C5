"""
evaluation/ground_truth.py
Deterministic Ground-Truth Verification Engine for Module M1.
Adopts verification concepts inspired by tau-bench and WorkBench.
Performs exact database assertions and state comparisons returning PASS/FAIL reports.
"""

import json
import os
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, asdict
from sqlalchemy.orm import Session
from sqlalchemy import func

from backend.database import SessionLocal
from backend.models import Employee, LeaveRecord, Department, SupportTicket, Payroll, Reimbursement


@dataclass
class VerificationResult:
    check_name: str
    target_id: str
    status: str  # "PASS" or "FAIL"
    expected: Any
    actual: Any
    explanation: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class GroundTruthVerifier:
    """
    Deterministic Verification Engine comparing candidate agent outputs and
    mock environment state against ground-truth database records and benchmark rubrics.
    """

    def __init__(self, db: Optional[Session] = None):
        self._db = db
        self._owns_session = False
        if self._db is None:
            self._db = SessionLocal()
            self._owns_session = True

    def close(self):
        if self._owns_session and self._db:
            self._db.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def verify_employee_existence(self, employee_id: str) -> VerificationResult:
        """Verifies if an employee ID exists in the enterprise database."""
        emp = self._db.query(Employee).filter(Employee.employee_id == employee_id).first()
        actual_exists = emp is not None

        if actual_exists:
            return VerificationResult(
                check_name="Employee Existence Check",
                target_id=employee_id,
                status="PASS",
                expected=True,
                actual=True,
                explanation=f"Employee '{employee_id}' exists in enterprise database ({emp.full_name}, {emp.department})."
            )
        else:
            return VerificationResult(
                check_name="Employee Existence Check",
                target_id=employee_id,
                status="FAIL",
                expected=True,
                actual=False,
                explanation=f"Employee '{employee_id}' was not found in enterprise database."
            )

    def verify_employee_details(
        self,
        employee_id: str,
        expected_details: Dict[str, Any]
    ) -> VerificationResult:
        """
        Deterministically asserts that specific employee attributes (department, role, status, etc.)
        match ground-truth database records.
        """
        emp = self._db.query(Employee).filter(Employee.employee_id == employee_id).first()
        if not emp:
            return VerificationResult(
                check_name="Employee Details Check",
                target_id=employee_id,
                status="FAIL",
                expected=expected_details,
                actual=None,
                explanation=f"Cannot verify details: Employee '{employee_id}' does not exist."
            )

        mismatches = []
        actual_details = {}
        for key, expected_val in expected_details.items():
            actual_val = getattr(emp, key, None)
            actual_details[key] = actual_val
            if str(actual_val).lower() != str(expected_val).lower():
                mismatches.append(f"Field '{key}': expected '{expected_val}', got '{actual_val}'")

        if not mismatches:
            return VerificationResult(
                check_name="Employee Details Check",
                target_id=employee_id,
                status="PASS",
                expected=expected_details,
                actual=actual_details,
                explanation=f"All {len(expected_details)} employee attributes for '{employee_id}' matched ground-truth records."
            )
        else:
            return VerificationResult(
                check_name="Employee Details Check",
                target_id=employee_id,
                status="FAIL",
                expected=expected_details,
                actual=actual_details,
                explanation=f"Attribute mismatches found: {'; '.join(mismatches)}."
            )

    def verify_leave_balance(
        self,
        employee_id: str,
        expected_remaining: int
    ) -> VerificationResult:
        """
        Calculates remaining leaves = total_annual_allocated - sum(approved_days)
        and asserts equality against expected_remaining.
        """
        emp = self._db.query(Employee).filter(Employee.employee_id == employee_id).first()
        if not emp:
            return VerificationResult(
                check_name="Leave Balance Verification",
                target_id=employee_id,
                status="FAIL",
                expected=expected_remaining,
                actual=None,
                explanation=f"Employee '{employee_id}' does not exist."
            )

        approved_sum = (
            self._db.query(func.coalesce(func.sum(LeaveRecord.days_requested), 0))
            .filter(
                LeaveRecord.employee_id == employee_id,
                LeaveRecord.status == "Approved"
            )
            .scalar()
        )

        latest_record = (
            self._db.query(LeaveRecord)
            .filter(LeaveRecord.employee_id == employee_id)
            .first()
        )
        total_quota = latest_record.total_annual_allocated if latest_record else 24
        actual_remaining = max(0, total_quota - int(approved_sum))

        if actual_remaining == expected_remaining:
            return VerificationResult(
                check_name="Leave Balance Verification",
                target_id=employee_id,
                status="PASS",
                expected=expected_remaining,
                actual=actual_remaining,
                explanation=(
                    f"Leave balance verified: Total quota ({total_quota}) - "
                    f"Approved leaves taken ({int(approved_sum)}) = {actual_remaining} days remaining."
                )
            )
        else:
            return VerificationResult(
                check_name="Leave Balance Verification",
                target_id=employee_id,
                status="FAIL",
                expected=expected_remaining,
                actual=actual_remaining,
                explanation=(
                    f"Leave balance mismatch for '{employee_id}': expected {expected_remaining}, "
                    f"calculated {actual_remaining} (Quota: {total_quota}, Taken: {int(approved_sum)})."
                )
            )

    def verify_task_outcome(
        self,
        task_id: str,
        candidate_output: Dict[str, Any]
    ) -> VerificationResult:
        """
        Loads task criteria from datasets/sample_tasks.json and verifies candidate output.
        """
        dataset_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "datasets",
            "sample_tasks.json"
        )
        with open(dataset_path, "r", encoding="utf-8") as f:
            tasks = json.load(f)

        target_task = next((t for t in tasks if t["task_id"] == task_id), None)
        if not target_task:
            return VerificationResult(
                check_name="Task Outcome Verification",
                target_id=task_id,
                status="FAIL",
                expected=None,
                actual=candidate_output,
                explanation=f"Task '{task_id}' not found in benchmark dataset."
            )

        expected_output = target_task["expected_output"]
        mismatches = []
        for key, exp_val in expected_output.items():
            if key not in candidate_output:
                mismatches.append(f"Missing required key '{key}'")
            elif candidate_output[key] != exp_val:
                mismatches.append(f"Key '{key}': expected '{exp_val}', got '{candidate_output[key]}'")

        if not mismatches:
            return VerificationResult(
                check_name=f"Task {task_id} Outcome Check",
                target_id=task_id,
                status="PASS",
                expected=expected_output,
                actual=candidate_output,
                explanation=f"Task outcome strictly conforms to ground truth criteria for {target_task['department']}."
            )
        else:
            return VerificationResult(
                check_name=f"Task {task_id} Outcome Check",
                target_id=task_id,
                status="FAIL",
                expected=expected_output,
                actual=candidate_output,
                explanation=f"Outcome discrepancy: {'; '.join(mismatches)}."
            )


if __name__ == "__main__":
    verifier = GroundTruthVerifier()
    print("--- RUNNING GROUND-TRUTH BASELINE CHECKS ---")
    
    # 1. Existence check
    res1 = verifier.verify_employee_existence("EMP-001")
    print(f"[{res1.status}] {res1.check_name}: {res1.explanation}")

    # 2. Details check
    res2 = verifier.verify_employee_details("EMP-001", {"full_name": "Alice Chen", "department": "Engineering"})
    print(f"[{res2.status}] {res2.check_name}: {res2.explanation}")

    # 3. Leave balance check
    res3 = verifier.verify_leave_balance("EMP-002", 18)
    print(f"[{res3.status}] {res3.check_name}: {res3.explanation}")

    # 4. Intentional FAIL check demonstration (negative test)
    res4 = verifier.verify_employee_existence("EMP-999")
    print(f"[{res4.status}] Negative Test (EMP-999): {res4.explanation}")

    verifier.close()
