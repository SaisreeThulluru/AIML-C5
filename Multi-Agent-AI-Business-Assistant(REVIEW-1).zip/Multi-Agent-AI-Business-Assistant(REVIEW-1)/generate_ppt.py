"""
generate_ppt.py
Generates the complete, professionally styled 10-slide PowerPoint presentation
for Week 1 Module M1 Major Project Review.
Team: AIML-C05 | Guide: Dr. Nuthi Raju
"""

import os
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

def create_presentation():
    prs = Presentation()
    # 16:9 Widescreen dimensions
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    # Color Palette
    NAVY = RGBColor(16, 37, 66)
    BLUE_ACCENT = RGBColor(0, 114, 206)
    DARK_GRAY = RGBColor(40, 44, 52)
    LIGHT_BG = RGBColor(244, 246, 249)
    WHITE = RGBColor(255, 255, 255)
    GREEN = RGBColor(46, 125, 50)
    CARD_BORDER = RGBColor(210, 218, 226)

    blank_layout = prs.slide_layouts[6]  # Blank slide

    def add_header(slide, title_text, category="MODULE M1: TASK SUITE, MOCK SYSTEMS & METRICS"):
        # Header banner card
        header_shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(0.4), Inches(11.733), Inches(0.95))
        header_shape.fill.solid()
        header_shape.fill.fore_color.rgb = WHITE
        header_shape.line.color.rgb = CARD_BORDER
        header_shape.line.width = Pt(1)

        # Category text
        cat_box = slide.shapes.add_textbox(Inches(1.0), Inches(0.45), Inches(11.3), Inches(0.3))
        cat_tf = cat_box.text_frame
        cat_tf.word_wrap = True
        p_cat = cat_tf.paragraphs[0]
        p_cat.text = category.upper()
        p_cat.font.size = Pt(10)
        p_cat.font.bold = True
        p_cat.font.color.rgb = BLUE_ACCENT

        # Title text
        title_box = slide.shapes.add_textbox(Inches(1.0), Inches(0.72), Inches(11.3), Inches(0.55))
        title_tf = title_box.text_frame
        title_tf.word_wrap = True
        p_title = title_tf.paragraphs[0]
        p_title.text = title_text
        p_title.font.size = Pt(20)
        p_title.font.bold = True
        p_title.font.color.rgb = NAVY

    def add_card(slide, left, top, width, height, title=None):
        card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
        card.fill.solid()
        card.fill.fore_color.rgb = WHITE
        card.line.color.rgb = CARD_BORDER
        card.line.width = Pt(1)

        if title:
            tb = slide.shapes.add_textbox(left + Inches(0.2), top + Inches(0.15), width - Inches(0.4), Inches(0.4))
            p = tb.text_frame.paragraphs[0]
            p.text = title
            p.font.size = Pt(13)
            p.font.bold = True
            p.font.color.rgb = NAVY

        return card

    # ==============================================================
    # SLIDE 1: TITLE SLIDE
    # ==============================================================
    slide1 = prs.slides.add_slide(blank_layout)

    # Background accent band
    band = slide1.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(13.333), Inches(3.2))
    band.fill.solid()
    band.fill.fore_color.rgb = NAVY
    band.line.fill.background()

    # Title text
    tb_title = slide1.shapes.add_textbox(Inches(1.0), Inches(0.7), Inches(11.333), Inches(1.8))
    tf1 = tb_title.text_frame
    tf1.word_wrap = True
    p1 = tf1.paragraphs[0]
    p1.text = "Multi-Agent AI Business Assistant"
    p1.font.size = Pt(32)
    p1.font.bold = True
    p1.font.color.rgb = WHITE

    p2 = tf1.add_paragraph()
    p2.text = "for Intelligent Enterprise Workflow Automation"
    p2.font.size = Pt(24)
    p2.font.bold = True
    p2.font.color.rgb = RGBColor(120, 190, 255)

    p3 = tf1.add_paragraph()
    p3.text = "B.Tech Final-Year Major Project • Module M1: Week 1 Foundation Implementation"
    p3.font.size = Pt(14)
    p3.font.color.rgb = RGBColor(200, 220, 245)

    # Details Cards
    card_meta = add_card(slide1, Inches(1.0), Inches(3.7), Inches(5.4), Inches(3.1), "Project Metadata")
    tf_meta = slide1.shapes.add_textbox(Inches(1.2), Inches(4.3), Inches(5.0), Inches(2.3)).text_frame
    tf_meta.word_wrap = True
    lines_meta = [
        ("Team ID:", " AIML-C05"),
        ("Branch:", " Computer Science & Engineering (AIML)"),
        ("Project Guide:", " Dr. Nuthi Raju"),
        ("Academic Year:", " 2026–2027"),
        ("Technologies:", " Python 3.10, FastAPI, SQLite, SQLAlchemy, Pytest")
    ]
    for label, val in lines_meta:
        p = tf_meta.add_paragraph()
        run1 = p.add_run()
        run1.text = label
        run1.font.bold = True
        run1.font.size = Pt(12)
        run1.font.color.rgb = NAVY
        run2 = p.add_run()
        run2.text = val
        run2.font.size = Pt(12)
        run2.font.color.rgb = DARK_GRAY

    card_obj = add_card(slide1, Inches(6.8), Inches(3.7), Inches(5.5), Inches(3.1), "Week 1 Foundation Scope")
    tf_obj = slide1.shapes.add_textbox(Inches(7.0), Inches(4.3), Inches(5.1), Inches(2.3)).text_frame
    tf_obj.word_wrap = True
    lines_obj = [
        "• Establish decoupled Python enterprise architecture",
        "• Formulate 15 checkable benchmark enterprise tasks",
        "• Build & seed 7-table SQLite mock database (enterprise.db)",
        "• Implement mock HR service & live FastAPI REST endpoints",
        "• Construct deterministic ground-truth verification engine",
        "• 21 automated unit tests with 100% pass rate in pytest"
    ]
    for line in lines_obj:
        p = tf_obj.add_paragraph()
        p.text = line
        p.font.size = Pt(11)
        p.font.color.rgb = DARK_GRAY

    slide1.notes_slide.notes_text_frame.text = (
        "Good morning Dr. Nuthi Raju Sir and panel members. We are presenting the Week 1 implementation "
        "of our Major Project: 'Multi-Agent AI Business Assistant for Intelligent Enterprise Workflow Automation'. "
        "We are Team AIML-C05. In Week 1, we established the robust foundation of Module M1, delivering "
        "15 benchmark tasks, an SQLite mock enterprise database, a mock HR service, FastAPI REST APIs, "
        "a deterministic ground-truth verification engine, and 21 automated pytest test cases."
    )

    # ==============================================================
    # SLIDE 2: PROJECT OVERVIEW & M1 ROADMAP
    # ==============================================================
    slide2 = prs.slides.add_slide(blank_layout)
    add_header(slide2, "Project Overview & Module M1 Evaluation Roadmap")

    # Left Card
    add_card(slide2, Inches(0.8), Inches(1.6), Inches(6.2), Inches(5.3), "Problem Statement & 3-Week Schedule")
    tf2 = slide2.shapes.add_textbox(Inches(1.0), Inches(2.2), Inches(5.8), Inches(4.5)).text_frame
    tf2.word_wrap = True

    pts2 = [
        ("The Enterprise Problem:", " Cross-department workflows (HR, Finance, Support, IT) currently require manual data navigation across fragmented, heterogeneous enterprise tools."),
        ("Proposed Solution:", " An autonomous Multi-Agent AI system with specialized domain agents coordinated by an orchestrator, executing verifiable API operations."),
        ("Module M1 - Week 1 (Current):", " Establish project foundation, 15 cross-department benchmark tasks, 7-table SQLite database, mock HR service, FastAPI backend, and ground truth engine."),
        ("Module M1 - Week 2 (Upcoming):", " Expand to 35 tasks, implement mock Finance/Payroll sandbox, sandbox email engine, and toy SQL warehouse."),
        ("Module M1 - Week 3 (Upcoming):", " Complete 50–60 tasks, ticketing system integration, and pass@k evaluation metrics harness.")
    ]
    for h, desc in pts2:
        p = tf2.add_paragraph()
        r1 = p.add_run()
        r1.text = h + "\n"
        r1.font.bold = True
        r1.font.size = Pt(11.5)
        r1.font.color.rgb = NAVY
        r2 = p.add_run()
        r2.text = desc + "\n"
        r2.font.size = Pt(10.5)
        r2.font.color.rgb = DARK_GRAY

    # Right Card: Screenshot Box
    add_card(slide2, Inches(7.3), Inches(1.6), Inches(5.2), Inches(5.3), "Project Architecture Structure")
    tf_img1 = slide2.shapes.add_textbox(Inches(7.5), Inches(2.3), Inches(4.8), Inches(4.3)).text_frame
    tf_img1.word_wrap = True
    p = tf_img1.add_paragraph()
    p.text = "[ATTACH SCREENSHOT: slide02_vscode_tree.png]\n"
    p.font.bold = True
    p.font.size = Pt(12)
    p.font.color.rgb = BLUE_ACCENT
    p_desc = tf_img1.add_paragraph()
    p_desc.text = (
        "Visual Proof: VS Code Left Sidebar Explorer Tree\n\n"
        "Shows clean, decoupled separation of:\n"
        "• backend/ (FastAPI routers, schemas, services)\n"
        "• database/ (enterprise.db SQLite instance)\n"
        "• datasets/ (sample_tasks.json benchmark suite)\n"
        "• evaluation/ (ground_truth.py engine)\n"
        "• tests/ (pytest automated suites)\n"
        "• research/ (literature_review.md)\n"
        "• docs/ (architecture.md & progress report)"
    )
    p_desc.font.size = Pt(10.5)
    p_desc.font.color.rgb = DARK_GRAY

    slide2.notes_slide.notes_text_frame.text = (
        "In Slide 2, we present our project roadmap. Module M1 spans 3 weeks. Instead of attempting the entire "
        "module in one week, we established the core foundation in Week 1. In the VS Code tree screenshot on the right, "
        "you can see our modular folder structure separating API routing, persistence, test suites, and literature reviews."
    )

    # ==============================================================
    # SLIDE 3: RESEARCH LITERATURE REVIEW
    # ==============================================================
    slide3 = prs.slides.add_slide(blank_layout)
    add_header(slide3, "Research Foundation: Adopting Concepts from τ-bench & WorkBench")

    add_card(slide3, Inches(0.8), Inches(1.6), Inches(6.2), Inches(5.3), "Academic Benchmark Analysis")
    tf3 = slide3.shapes.add_textbox(Inches(1.0), Inches(2.2), Inches(5.8), Inches(4.5)).text_frame
    tf3.word_wrap = True

    pts3 = [
        ("Why Standard LLM Benchmarks Fail:", " Benchmarks like MMLU or HumanEval only evaluate static question answering or isolated code syntax; they cannot evaluate dynamic enterprise environment state changes."),
        ("1. τ-bench (UC Berkeley, 2024 - arXiv:2406.12045):", " Evaluates agents interacting with relational databases under strict policy rules. Key concept adopted: Inspecting final database state directly rather than relying on subjective 'LLM-as-a-judge' text evaluation."),
        ("2. WorkBench (Stanford University, 2024 - arXiv:2405.00823):", " Evaluates multi-turn, multi-tool enterprise workflows. Key concept adopted: Standardized 8-field JSON task rubrics, cross-department stratification, and difficulty tiers (Easy/Medium/Hard)."),
        ("Methodological Synthesis for M1:", " Combines WorkBench's structured task schemas with τ-bench's deterministic database state verification engine.")
    ]
    for h, desc in pts3:
        p = tf3.add_paragraph()
        r1 = p.add_run()
        r1.text = h + "\n"
        r1.font.bold = True
        r1.font.size = Pt(11)
        r1.font.color.rgb = NAVY
        r2 = p.add_run()
        r2.text = desc + "\n"
        r2.font.size = Pt(10)
        r2.font.color.rgb = DARK_GRAY

    add_card(slide3, Inches(7.3), Inches(1.6), Inches(5.2), Inches(5.3), "Literature Reference")
    tf_img3 = slide3.shapes.add_textbox(Inches(7.5), Inches(2.3), Inches(4.8), Inches(4.3)).text_frame
    tf_img3.word_wrap = True
    p = tf_img3.add_paragraph()
    p.text = "[ATTACH SCREENSHOT: slide03_research_papers.png]\n"
    p.font.bold = True
    p.font.size = Pt(12)
    p.font.color.rgb = BLUE_ACCENT
    p_desc = tf_img3.add_paragraph()
    p_desc.text = (
        "Foundational Research Papers Studied:\n\n"
        "1. 'τ-bench: A Benchmark for Tool-Agent-User Interaction in Real-World Environments'\n"
        "   Authors: Shunyu Liu et al. (UC Berkeley & Princeton)\n"
        "   Key insight: Deterministic DB state evaluation\n\n"
        "2. 'WorkBench: Benchmarking Multi-Task Enterprise Agents with Complex Workflows'\n"
        "   Authors: Tianbao Xie et al. (Stanford University)\n"
        "   Key insight: Structured cross-department rubrics\n\n"
        "Documented in full in: research/literature_review.md"
    )
    p_desc.font.size = Pt(10.5)
    p_desc.font.color.rgb = DARK_GRAY

    slide3.notes_slide.notes_text_frame.text = (
        "Slide 3 shows our academic literature review. We studied τ-bench from Berkeley and WorkBench from Stanford. "
        "Traditional benchmarks like MMLU suffer from hallucination and prompt gaming. τ-bench proved that evaluating "
        "agents by inspecting the final database state is the gold standard, while WorkBench provided the structured "
        "rubric schema we implemented in our task suite."
    )

    # ==============================================================
    # SLIDE 4: ENTERPRISE TAXONOMY (6 DOMAINS)
    # ==============================================================
    slide4 = prs.slides.add_slide(blank_layout)
    add_header(slide4, "Enterprise Taxonomy: 6 Core Business Domains Covered")

    domains = [
        ("1. Human Resources (HR)", "Employee onboarding records, department transfers, annual leave balances (24-day quota).", Inches(0.8), Inches(1.6)),
        ("2. Finance & Payroll", "Monthly net salary calculations, tax (TDS) and PF deductions, travel reimbursement policy audits.", Inches(4.8), Inches(1.6)),
        ("3. Software Engineering", "Production crash log severity triage (Sev-1 vs Sev-3), Conventional Commits message compliance.", Inches(8.8), Inches(1.6)),
        ("4. Email Communication", "Executive budget approval drafting, service outage post-mortem briefings to department heads.", Inches(0.8), Inches(4.3)),
        ("5. Data Analytics", "Q3 regional sales revenue aggregation, departmental turnover rates, low-inventory safety alerts.", Inches(4.8), Inches(4.3)),
        ("6. Customer Support", "Incident domain categorization, SLA response window calculation, customer satisfaction (CSAT) verification.", Inches(8.8), Inches(4.3)),
    ]

    for title, desc, left, top in domains:
        add_card(slide4, left, top, Inches(3.7), Inches(2.5), title)
        tb = slide4.shapes.add_textbox(left + Inches(0.2), top + Inches(0.7), Inches(3.3), Inches(1.6))
        tb.text_frame.word_wrap = True
        p = tb.text_frame.paragraphs[0]
        p.text = desc
        p.font.size = Pt(11)
        p.font.color.rgb = DARK_GRAY

    slide4.notes_slide.notes_text_frame.text = (
        "In Slide 4, we define our enterprise taxonomy across 6 essential business departments. Each department "
        "has specific business logic, constraints, and operational tools. This breadth ensures that our multi-agent assistant "
        "is trained and evaluated against real-world enterprise scenarios."
    )

    # ==============================================================
    # SLIDE 5: SYSTEM ARCHITECTURE & SQLITE MOCK DB
    # ==============================================================
    slide5 = prs.slides.add_slide(blank_layout)
    add_header(slide5, "System Architecture & Mock Database (enterprise.db)")

    add_card(slide5, Inches(0.8), Inches(1.6), Inches(6.2), Inches(5.3), "Relational Database & ORM Models")
    tf5 = slide5.shapes.add_textbox(Inches(1.0), Inches(2.2), Inches(5.8), Inches(4.5)).text_frame
    tf5.word_wrap = True

    pts5 = [
        ("Architecture Tiers:", " 3-Tier decoupled pattern: FastAPI Controllers → Python Business Service Layer → SQLAlchemy ORM Persistence."),
        ("Database Engine:", " SQLite 3 relational database located at database/enterprise.db."),
        ("7 Core Enterprise Tables Implemented & Seeded:", ""),
        ("• departments:", " 6 records (HR, Finance, Eng, QA, Support, Marketing) with budgets."),
        ("• employees:", " 5 employee profiles with salaries, roles, joining dates, and departments."),
        ("• leave_records:", " Records with quotas (24 days), dates, and approved/pending states."),
        ("• payroll:", " Payslips with base, allowances, gross, tax, PF, and net salary."),
        ("• reimbursements:", " Expense claims with policy caps ($5000 audit threshold)."),
        ("• email_drafts & support_tickets:", " Incident communication drafts & support tickets with SLAs.")
    ]
    for h, desc in pts5:
        p = tf5.add_paragraph()
        r1 = p.add_run()
        r1.text = h + " "
        r1.font.bold = True
        r1.font.size = Pt(10.5)
        r1.font.color.rgb = NAVY
        r2 = p.add_run()
        r2.text = desc
        r2.font.size = Pt(10.5)
        r2.font.color.rgb = DARK_GRAY

    add_card(slide5, Inches(7.3), Inches(1.6), Inches(5.2), Inches(5.3), "Relational ER Diagram")
    tf_img5 = slide5.shapes.add_textbox(Inches(7.5), Inches(2.3), Inches(4.8), Inches(4.3)).text_frame
    tf_img5.word_wrap = True
    p = tf_img5.add_paragraph()
    p.text = "[ATTACH SCREENSHOT: slide05_database_schema.png]\n"
    p.font.bold = True
    p.font.size = Pt(12)
    p.font.color.rgb = BLUE_ACCENT
    p_desc = tf_img5.add_paragraph()
    p_desc.text = (
        "Database Architecture Highlights:\n\n"
        "• Foreign Key Relationships:\n"
        "  - employees.department → departments.name\n"
        "  - leave_records.employee_id → employees.employee_id\n"
        "  - payroll.employee_id → employees.employee_id\n"
        "  - reimbursements.employee_id → employees.employee_id\n\n"
        "• Fully seeded with fictional benchmark records\n"
        "• Managed via backend/models.py & backend/database.py"
    )
    p_desc.font.size = Pt(10.5)
    p_desc.font.color.rgb = DARK_GRAY

    slide5.notes_slide.notes_text_frame.text = (
        "Slide 5 details our database architecture. We implemented an SQLite relational database with 7 tables "
        "managed by SQLAlchemy ORM models. Foreign keys maintain strict relational integrity between employees, "
        "leave requests, payroll slips, and expense claims. The ER diagram on the right illustrates these entity relationships."
    )

    # ==============================================================
    # SLIDE 6: BENCHMARK TASK DATASET (15 TASKS)
    # ==============================================================
    slide6 = prs.slides.add_slide(blank_layout)
    add_header(slide6, "Initial Enterprise Task Dataset (sample_tasks.json)")

    add_card(slide6, Inches(0.8), Inches(1.6), Inches(6.2), Inches(5.3), "Standardized Task Specification Schema")
    tf6 = slide6.shapes.add_textbox(Inches(1.0), Inches(2.2), Inches(5.8), Inches(4.5)).text_frame
    tf6.word_wrap = True

    pts6 = [
        ("Task Suite Size:", " 15 realistic enterprise benchmark tasks covering all 6 departments."),
        ("Mandatory 8-Field Schema:", " Adopted from Stanford WorkBench for deterministic automated grading:"),
        ("1. task_id:", " Unique string identifier (e.g. TASK-HR-001, TASK-FIN-002)."),
        ("2. department:", " Enterprise domain responsible for execution."),
        ("3. task_description:", " Operational natural-language instruction."),
        ("4. input_parameters:", " Structured input payload provided to agent/tool."),
        ("5. expected_output:", " Expected return dictionary for verification."),
        ("6. expected_outcome:", " Verifiable narrative real-world business outcome."),
        ("7. verification_criteria:", " Exact database assertion rule and comparison target."),
        ("8. difficulty_level:", " Tiered across Easy, Medium, and Hard complexity.")
    ]
    for h, desc in pts6:
        p = tf6.add_paragraph()
        r1 = p.add_run()
        r1.text = h + " "
        r1.font.bold = True
        r1.font.size = Pt(10.5)
        r1.font.color.rgb = NAVY
        r2 = p.add_run()
        r2.text = desc
        r2.font.size = Pt(10.5)
        r2.font.color.rgb = DARK_GRAY

    add_card(slide6, Inches(7.3), Inches(1.6), Inches(5.2), Inches(5.3), "Dataset Implementation")
    tf_img6 = slide6.shapes.add_textbox(Inches(7.5), Inches(2.3), Inches(4.8), Inches(4.3)).text_frame
    tf_img6.word_wrap = True
    p = tf_img6.add_paragraph()
    p.text = "[ATTACH SCREENSHOT: slide06_tasks_dataset.png]\n"
    p.font.bold = True
    p.font.size = Pt(12)
    p.font.color.rgb = BLUE_ACCENT
    p_desc = tf_img6.add_paragraph()
    p_desc.text = (
        "Dataset Highlights (datasets/sample_tasks.json):\n\n"
        "• TASK-HR-002 Example (shown in screenshot):\n"
        "  - ID: TASK-HR-002\n"
        "  - Dept: Human Resources\n"
        "  - Input: {employee_id: 'EMP-002'}\n"
        "  - Expected Output: total=24, approved=6, remaining=18\n"
        "  - Verification Rule: total_allocated - sum(approved_days)\n"
        "  - Difficulty: Medium\n\n"
        "• Stratified across 6 departments with zero missing fields."
    )
    p_desc.font.size = Pt(10.5)
    p_desc.font.color.rgb = DARK_GRAY

    slide6.notes_slide.notes_text_frame.text = (
        "Slide 6 presents our benchmark task suite stored in datasets/sample_tasks.json. Every task adheres "
        "to an 8-field standardized schema with clear input parameters, expected outputs, and explicit verification rules. "
        "This machine-readable dataset allows automated evaluation scripts to grade agent performance deterministically."
    )

    # ==============================================================
    # SLIDE 7: MOCK HR SYSTEM & FASTAPI BACKEND
    # ==============================================================
    slide7 = prs.slides.add_slide(blank_layout)
    add_header(slide7, "Mock HR System & FastAPI REST Backend")

    add_card(slide7, Inches(0.8), Inches(1.6), Inches(6.2), Inches(5.3), "RESTful API Endpoints & Business Logic")
    tf7 = slide7.shapes.add_textbox(Inches(1.0), Inches(2.2), Inches(5.8), Inches(4.5)).text_frame
    tf7.word_wrap = True

    pts7 = [
        ("Framework:", " FastAPI with Uvicorn ASGI server and Pydantic serialization models."),
        ("Architecture Decoupling:", " Routes in backend/routes/ delegate business queries to backend/services/hr_service.py for pure unit testability."),
        ("Key Implemented Endpoints:", ""),
        ("• GET /employees:", " Lists all employees with optional ?department= and ?search= query filters."),
        ("• GET /employees/{id}:", " Fetches single employee profile; returns HTTP 404 for missing IDs."),
        ("• GET /employees/{id}/leave:", " Dynamically computes remaining leave balance:"),
        ("  Formula:", " Total Allocated (24) - Approved Leaves Taken (6) = 18 Days."),
        ("• GET /tasks:", " Returns benchmark tasks with ?department= and ?difficulty= filters."),
        ("Interactive Docs:", " OpenAPI Swagger UI accessible live at http://127.0.0.1:8000/docs.")
    ]
    for h, desc in pts7:
        p = tf7.add_paragraph()
        r1 = p.add_run()
        r1.text = h + " "
        r1.font.bold = True
        r1.font.size = Pt(10.5)
        r1.font.color.rgb = NAVY
        r2 = p.add_run()
        r2.text = desc
        r2.font.size = Pt(10.5)
        r2.font.color.rgb = DARK_GRAY

    add_card(slide7, Inches(7.3), Inches(1.6), Inches(5.2), Inches(5.3), "Live API Execution")
    tf_img7 = slide7.shapes.add_textbox(Inches(7.5), Inches(2.3), Inches(4.8), Inches(4.3)).text_frame
    tf_img7.word_wrap = True
    p = tf_img7.add_paragraph()
    p.text = "[ATTACH: slide07_swagger_docs.png & slide07_leave_api_response.png]\n"
    p.font.bold = True
    p.font.size = Pt(11)
    p.font.color.rgb = BLUE_ACCENT
    p_desc = tf_img7.add_paragraph()
    p_desc.text = (
        "Live Swagger Execution Verification:\n\n"
        "• URL: http://127.0.0.1:8000/docs\n"
        "• Executed: GET /employees/EMP-002/leave\n"
        "• Response Code: 200 OK\n"
        "• Response Payload:\n"
        "  {\n"
        "    'employee_id': 'EMP-002',\n"
        "    'full_name': 'Bob Smith',\n"
        "    'department': 'Finance',\n"
        "    'total_allocated': 24,\n"
        "    'approved_leaves_taken': 6,\n"
        "    'remaining_leaves': 18\n"
        "  }"
    )
    p_desc.font.size = Pt(10)
    p_desc.font.color.rgb = DARK_GRAY

    slide7.notes_slide.notes_text_frame.text = (
        "Slide 7 shows our live FastAPI backend. In Swagger UI at /docs, we executed the leave balance endpoint "
        "for employee EMP-002. Our HR service layer aggregated all approved leaves from the database, deducted them "
        "from the 24-day quota, and returned exactly 18 remaining leaves in 200 OK JSON format."
    )

    # ==============================================================
    # SLIDE 8: GROUND-TRUTH VERIFICATION ENGINE
    # ==============================================================
    slide8 = prs.slides.add_slide(blank_layout)
    add_header(slide8, "Deterministic Ground-Truth Verification Engine")

    add_card(slide8, Inches(0.8), Inches(1.6), Inches(6.2), Inches(5.3), "State-Based Verification Design")
    tf8 = slide8.shapes.add_textbox(Inches(1.0), Inches(2.2), Inches(5.8), Inches(4.5)).text_frame
    tf8.word_wrap = True

    pts8 = [
        ("Zero-Hallucination Design:", " Built in evaluation/ground_truth.py. Uses strict deterministic database state checks rather than subjective LLM evaluation."),
        ("Verification Checks Implemented:", ""),
        ("1. Employee Existence Verification:", " Confirms presence of employee ID in SQLite records; flags missing IDs."),
        ("2. Employee Attribute Details:", " Compares actual database fields against expected dictionaries (department, role, salary)."),
        ("3. Mathematical Leave Verification:", " Asserts equality between calculated remaining quota and benchmark expected values:"),
        ("   Calculation:", " Remaining = 24 - sum(approved_days)."),
        ("4. Task Outcome Verification:", " Evaluates candidate agent output against target expected_output from sample_tasks.json."),
        ("Standardized Result Format:", " Returns VerificationResult(check_name, status, expected, actual, explanation).")
    ]
    for h, desc in pts8:
        p = tf8.add_paragraph()
        r1 = p.add_run()
        r1.text = h + " "
        r1.font.bold = True
        r1.font.size = Pt(10.5)
        r1.font.color.rgb = NAVY
        r2 = p.add_run()
        r2.text = desc
        r2.font.size = Pt(10.5)
        r2.font.color.rgb = DARK_GRAY

    add_card(slide8, Inches(7.3), Inches(1.6), Inches(5.2), Inches(5.3), "Verification Terminal Output")
    tf_img8 = slide8.shapes.add_textbox(Inches(7.5), Inches(2.3), Inches(4.8), Inches(4.3)).text_frame
    tf_img8.word_wrap = True
    p = tf_img8.add_paragraph()
    p.text = "[ATTACH SCREENSHOT: slide08_ground_truth_output.png]\n"
    p.font.bold = True
    p.font.size = Pt(12)
    p.font.color.rgb = BLUE_ACCENT
    p_desc = tf_img8.add_paragraph()
    p_desc.text = (
        "Terminal Output Proof (python -m evaluation.ground_truth):\n\n"
        "• [PASS] Employee Existence: EMP-001 found (Alice Chen, Engineering)\n"
        "• [PASS] Employee Details: All attributes matched ground truth\n"
        "• [PASS] Leave Balance: Verified 24 - 6 = 18 days remaining\n"
        "• [FAIL] Negative Test: EMP-999 correctly detected as non-existent\n\n"
        "Provides clear explanations and actual/expected values for every check."
    )
    p_desc.font.size = Pt(10.5)
    p_desc.font.color.rgb = DARK_GRAY

    slide8.notes_slide.notes_text_frame.text = (
        "Slide 8 presents our ground_truth.py verification engine. As shown in the terminal output, the engine performs "
        "deterministic database queries. It produces PASS when actual state matches expected criteria, and correctly "
        "produces FAIL on negative test cases with diagnostic explanations."
    )

    # ==============================================================
    # SLIDE 9: AUTOMATED PYTEST HARNESS (21/21 PASSED)
    # ==============================================================
    slide9 = prs.slides.add_slide(blank_layout)
    add_header(slide9, "Automated Testing & Validation: 21 of 21 Tests Passed")

    add_card(slide9, Inches(0.8), Inches(1.6), Inches(6.2), Inches(5.3), "Test Suites & Quality Engineering")
    tf9 = slide9.shapes.add_textbox(Inches(1.0), Inches(2.2), Inches(5.8), Inches(4.5)).text_frame
    tf9.word_wrap = True

    pts9 = [
        ("Testing Framework:", " pytest 7.0 with session-scoped database fixtures (tests/conftest.py)."),
        ("4 Comprehensive Test Suites Authoring 21 Test Cases:", ""),
        ("1. test_database.py (3 tests):", " Asserts all 7 tables exist, validates minimum seed counts, and verifies relational joins."),
        ("2. test_hr.py (7 tests):", " Tests full directory retrieval, department filtering, keyword search, and leave balance math."),
        ("3. test_tasks.py (4 tests):", " Validates 15 tasks count, coverage of all 6 departments, unique IDs, and mandatory schema keys."),
        ("4. test_ground_truth.py (7 tests):", " Validates positive PASS assertions and negative FAIL detection on missing entities."),
        ("Execution Performance:", " 21 passed in 0.23 seconds (100% pass rate).")
    ]
    for h, desc in pts9:
        p = tf9.add_paragraph()
        r1 = p.add_run()
        r1.text = h + " "
        r1.font.bold = True
        r1.font.size = Pt(10.5)
        r1.font.color.rgb = NAVY
        r2 = p.add_run()
        r2.text = desc
        r2.font.size = Pt(10.5)
        r2.font.color.rgb = DARK_GRAY

    add_card(slide9, Inches(7.3), Inches(1.6), Inches(5.2), Inches(5.3), "Pytest Execution Output")
    tf_img9 = slide9.shapes.add_textbox(Inches(7.5), Inches(2.3), Inches(4.8), Inches(4.3)).text_frame
    tf_img9.word_wrap = True
    p = tf_img9.add_paragraph()
    p.text = "[ATTACH SCREENSHOT: slide09_pytest_21_passed.png]\n"
    p.font.bold = True
    p.font.size = Pt(12)
    p.font.color.rgb = GREEN
    p_desc = tf_img9.add_paragraph()
    p_desc.text = (
        "Pytest Results Summary:\n\n"
        "• tests/test_database.py: 3 PASSED\n"
        "• tests/test_ground_truth.py: 7 PASSED\n"
        "• tests/test_hr.py: 7 PASSED\n"
        "• tests/test_tasks.py: 4 PASSED\n\n"
        "================ 21 passed in 0.23s ================\n\n"
        "100% Automated Test Pass Rate achieved."
    )
    p_desc.font.size = Pt(11)
    p_desc.font.color.rgb = DARK_GRAY

    slide9.notes_slide.notes_text_frame.text = (
        "Slide 9 demonstrates our automated test engineering. We wrote 21 pytest test cases across database integrity, "
        "HR service functions, task schema validation, and ground-truth assertions. In the terminal screenshot on the right, "
        "all 21 tests pass with 100% success in under 0.3 seconds."
    )

    # ==============================================================
    # SLIDE 10: DELIVERABLES SUMMARY & WEEK 2 PLAN
    # ==============================================================
    slide10 = prs.slides.add_slide(blank_layout)
    add_header(slide10, "Week 1 Deliverables Summary & Week 2 Action Plan")

    add_card(slide10, Inches(0.8), Inches(1.6), Inches(5.6), Inches(5.3), "Week 1 Completed Deliverables")
    tf10_left = slide10.shapes.add_textbox(Inches(1.0), Inches(2.2), Inches(5.2), Inches(4.5)).text_frame
    tf10_left.word_wrap = True

    pts10_l = [
        "✅ Clean, decoupled Python project architecture & venv",
        "✅ 15 enterprise tasks defined in JSON across 6 departments",
        "✅ SQLite relational database (7 tables) with seed records",
        "✅ Mock HR system service functions (search, info, leave)",
        "✅ FastAPI REST backend with OpenAPI Swagger docs (/docs)",
        "✅ Deterministic ground-truth verification engine",
        "✅ Automated pytest test harness (21/21 passing tests)",
        "✅ Academic literature review (τ-bench & WorkBench)",
        "✅ System architecture specifications (docs/architecture.md)",
        "✅ Comprehensive Week 1 academic progress report"
    ]
    for line in pts10_l:
        p = tf10_left.add_paragraph()
        p.text = line
        p.font.size = Pt(11)
        p.font.color.rgb = DARK_GRAY

    add_card(slide10, Inches(6.8), Inches(1.6), Inches(5.7), Inches(5.3), "Week 2 Upcoming Action Plan")
    tf10_right = slide10.shapes.add_textbox(Inches(7.0), Inches(2.2), Inches(5.3), Inches(4.5)).text_frame
    tf10_right.word_wrap = True

    pts10_r = [
        "🔄 Expand Task Suite: Add 20 tasks (target: 35 total) covering multi-step finance approvals, SQL warehouse joins, and email notifications.",
        "🔄 Mock Finance/Payroll Sandbox: Implement /finance/payroll/calculate and /finance/reimbursements/audit API endpoints.",
        "🔄 Mock Email Engine: Build simulated SMTP inbox with sent draft validation.",
        "🔄 Toy SQL Warehouse: Implement aggregate analytical queries over synthetic sales and inventory databases.",
        "🔄 Multi-Step State Checkers: Implement sequential state verification across dependent actions (e.g. Employee Created → Leave Allocated → Email Dispatched)."
    ]
    for line in pts10_r:
        p = tf10_right.add_paragraph()
        p.text = line
        p.font.size = Pt(11)
        p.font.color.rgb = DARK_GRAY

    slide10.notes_slide.notes_text_frame.text = (
        "In our final slide, we summarize our completed Week 1 foundation deliverables and transparently outline "
        "our Week 2 action plan. We completed all 10 Week 1 objectives. Next week, we will expand our task suite to 35 tasks "
        "and implement the Finance, Email, and SQL warehouse sandboxes. Thank you, Sir. We are now open for questions."
    )

    output_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Week1_Project_Presentation.pptx")
    prs.save(output_path)
    print(f"PowerPoint Presentation generated successfully at: {output_path}")

if __name__ == "__main__":
    create_presentation()
